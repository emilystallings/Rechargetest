/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 403);
/******/ })
/************************************************************************/
/******/ ({

/***/ 1:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export pipe */
/* unused harmony export compose */
/* unused harmony export map */
/* unused harmony export filter */
/* unused harmony export pluck */
/* unused harmony export sort */
/* unused harmony export mapDOMElements */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return selectAll; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return selectArr; });
/* unused harmony export select */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return selectDoc; });
/* unused harmony export value */
/* unused harmony export getElems */
/* unused harmony export dataValue */
/* unused harmony export removeAttribute */
/* unused harmony export closest */
/* unused harmony export remove */
/* unused harmony export nextSibling */
/* unused harmony export prevSibling */
/* unused harmony export toggleAttr */
/* unused harmony export setAttr */
/* unused harmony export getAttr */
/* unused harmony export submit */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "l", function() { return toggleClass; });
/* unused harmony export setText */
/* unused harmony export setHtml */
/* unused harmony export opacity */
/* unused harmony export styles */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return hasClass; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return isVisible; });
/* unused harmony export removeClassAll */
/* unused harmony export addClassAll */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return addClass; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return removeClass; });
/* unused harmony export toggleClassAll */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return event; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return ajax; });
/* unused harmony export observeAdd */
/* unused harmony export observeRemove */
/* unused harmony export cartesian */
/* unused harmony export count */
/* unused harmony export goTo */
/* unused harmony export insertSortedValue */
/* unused harmony export serialize */
/* unused harmony export getQueryValue */
/* unused harmony export asyncForEach */
/* unused harmony export MONEY_FORMATS */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return formatMoney; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return imageSize; });
function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e2) { throw _e2; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e3) { didErr = true; err = _e3; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/*
  The purpose of this file is generate/introduce a toolbelt (Similar to loadash, Ramda, RxJS)
  following the DRY principle and functional programming practices
*/

/*
 Composition functions
*/

/*
  Pipe is a function to create composition of functions (using map, filter, sort, etc)
  Usage example: https://www.freecodecamp.org/news/pipe-and-compose-in-javascript-5b04004ac937/
  External resources: https://medium.com/javascript-scene/tagged/functional-programming
*/
var pipe = function pipe() {
  for (var _len = arguments.length, fns = new Array(_len), _key = 0; _key < _len; _key++) {
    fns[_key] = arguments[_key];
  }

  return function (x) {
    return fns.reduce(function (v, f) {
      return f(v);
    }, x);
  };
};
var compose = function compose() {
  for (var _len2 = arguments.length, fns = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    fns[_key2] = arguments[_key2];
  }

  return function (x) {
    return fns.reduceRight(function (v, f) {
      return f(v);
    }, x);
  };
};
var map = function map(f) {
  return function (arr) {
    return arr.reduce(function (acc, x) {
      return [].concat(_toConsumableArray(acc), [f(x)]);
    }, []);
  };
};
var filter = function filter(f) {
  return function (arr) {
    return arr.reduce(function (acc, x) {
      return f(x) ? [].concat(_toConsumableArray(acc), [x]) : acc;
    }, []);
  };
};
var pluck = function pluck(str) {
  return function (arr) {
    return arr.reduce(function (acc, x) {
      return [].concat(_toConsumableArray(acc), [_defineProperty({}, str, x[str])]);
    }, []);
  };
};
var sort = function sort(fn) {
  return function (arr) {
    return arr.reduce(insertSortedValue(fn), []);
  };
};
/*
  General DOM functions
  Use these functions to select, handle html elements (similar to jQuery)
*/
//Apply/Loop function to a group of html elements

var mapDOMElements = function mapDOMElements(fn) {
  return function (items) {
    return _toConsumableArray(items).forEach(fn);
  };
};
var selectAll = function selectAll(query) {
  var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return item.querySelectorAll(query);
};
var selectArr = function selectArr(query) {
  var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return [].slice.call(item.querySelectorAll(query));
};
var select = function select() {
  var item = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : document;
  var query = arguments.length > 1 ? arguments[1] : undefined;
  return item.querySelector(query);
};
var selectDoc = function selectDoc(query) {
  var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return item.querySelector(query);
};
var value = function value(query) {
  var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return item.querySelector(query).value;
}; //General query for elements equivalent to $()

var getElems = function getElems(query) {
  var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return _toConsumableArray(item.querySelectorAll(query));
};
var dataValue = function dataValue(_ref2) {
  var dataset = _ref2.dataset;
  return function (id) {
    return dataset[id];
  };
};
/*
  General DOM functions
  Use these functions to update html elements (similar to jQuery)
*/

var removeAttribute = function removeAttribute(tag) {
  return function (item) {
    return item.removeAttribute(tag);
  };
};
var closest = function closest(item) {
  return function (query) {
    return item.closest(query);
  };
};
var remove = function remove(item) {
  return item.parentNode.removeChild(item);
};
var nextSibling = function nextSibling(item) {
  return item.nextElementSibling;
};
var prevSibling = function prevSibling(item) {
  return item.previousElementSibling;
};
var toggleAttr = function toggleAttr(item, attr) {
  return item.toggleAttribute(attr);
};
var setAttr = function setAttr(attr, value) {
  return function (item) {
    return item.setAttribute(attr, value);
  };
};
var getAttr = function getAttr(attr) {
  return function (item) {
    return item.getAttribute(attr);
  };
};
var submit = function submit(item) {
  return item.submit(item);
};
var toggleClass = function toggleClass(item, cls) {
  return item.classList.toggle(cls);
};
var setText = function setText(item) {
  return function (text) {
    return item.innerText = text;
  };
};
var setHtml = function setHtml(item) {
  return function (html) {
    return item.innerHTML = html;
  };
};
var opacity = function opacity(value) {
  return function (item) {
    return item.style.opacity = "".concat(value);
  };
};
var styles = function styles(elem, _styles) {
  return elem.setAttribute("style", Object.entries(_styles).map(function (_ref3) {
    var _ref4 = _slicedToArray(_ref3, 2),
        key = _ref4[0],
        value = _ref4[1];

    return "".concat(key, ": ").concat(value, ";");
  }).join(' '));
};
/*
jpgg
*/

var hasClass = function hasClass(target, className) {
  return new RegExp('(\\s|^)' + className + '(\\s|$)').test(target.className);
};
var isVisible = function isVisible(elem) {
  return !!elem && !!(elem.offsetWidth || elem.offsetHeight || elem.getClientRects().length);
}; // source (2018-03-11): https://github.com/jquery/jquery/blob/master/src/css/hiddenVisibleSelectors.js

var removeClassAll = function removeClassAll(list, cls) {
  return list.map(function (l) {
    return l.classList.remove(cls);
  });
};
var addClassAll = function addClassAll(list, cls) {
  return list.map(function (l) {
    return l.classList.add(cls);
  });
};
var addClass = function addClass(e, cls) {
  return !hasClass(e, cls) ? e.classList.add(cls) : false;
};
var removeClass = function removeClass(e, cls) {
  return hasClass(e, cls) ? e.classList.remove(cls) : false;
};
var toggleClassAll = function toggleClassAll(items, cls) {
  return [].slice.call(items).map(function (item) {
    return item.classList.toggle(cls);
  });
};
var event = function event(elem, _event, func) {
  return elem ? elem.addEventListener(_event, func) : console.log('Invalid element to apply ' + _event + ': ' + func);
};
var ajax = /*#__PURE__*/function () {
  var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(method, url) {
    var data,
        contentType,
        xhttp,
        _args = arguments;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            data = _args.length > 2 && _args[2] !== undefined ? _args[2] : {};
            contentType = _args.length > 3 && _args[3] !== undefined ? _args[3] : 'application/json';
            xhttp = _args.length > 4 && _args[4] !== undefined ? _args[4] : null;
            return _context.abrupt("return", new Promise(function (resolve) {
              if (!xhttp) {
                xhttp = new XMLHttpRequest();
              }

              xhttp.onreadystatechange = function () {
                if (xhttp.readyState === 4) {
                  resolve(JSON.stringify({
                    status: xhttp.status,
                    response: xhttp.responseText
                  }));
                }
              };

              xhttp.open(method, url, true);

              if (method === 'POST' && data) {
                xhttp.setRequestHeader('Content-type', contentType);
                xhttp.send(data);
              } else {
                xhttp.send();
              }

              return xhttp;
            }));

          case 4:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function ajax(_x, _x2) {
    return _ref5.apply(this, arguments);
  };
}();
var observeAdd = /*#__PURE__*/function () {
  var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(container, callback) {
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            new MutationObserver(function (mutationsList, observer) {
              var _iterator = _createForOfIteratorHelper(mutationsList),
                  _step;

              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var mutation = _step.value;

                  if (mutation.type === 'childList') {
                    var nodes = [].slice.call(mutation.addedNodes);

                    if (nodes.length > 0) {
                      callback(nodes);
                    }
                  }
                }
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
            }).observe(container, {
              attributes: true,
              childList: true,
              subtree: true
            });

          case 1:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));

  return function observeAdd(_x3, _x4) {
    return _ref6.apply(this, arguments);
  };
}();
var observeRemove = /*#__PURE__*/function () {
  var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(container, callback) {
    return regeneratorRuntime.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            new MutationObserver(function (mutationsList, observer) {
              var _iterator2 = _createForOfIteratorHelper(mutationsList),
                  _step2;

              try {
                for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                  var mutation = _step2.value;

                  if (mutation.type === 'childList') {
                    var nodes = [].slice.call(mutation.removedNodes);

                    if (nodes.length > 0) {
                      callback(nodes);
                    }
                  }
                }
              } catch (err) {
                _iterator2.e(err);
              } finally {
                _iterator2.f();
              }
            }).observe(container, {
              attributes: true,
              childList: true,
              subtree: true
            });

          case 1:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));

  return function observeRemove(_x5, _x6) {
    return _ref7.apply(this, arguments);
  };
}();
var cartesian = function cartesian() {
  for (var _len3 = arguments.length, a = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
    a[_key3] = arguments[_key3];
  }

  return a.reduce(function (a, b) {
    return a.flatMap(function (d) {
      return b.map(function (e) {
        return [d, e].flat();
      });
    });
  });
};
/*
  General purpose functions
  Use these functions to apply certain operation in your context
*/

var count = function count(str) {
  return str.length;
};
var goTo = function goTo(URL) {
  return window.location.href = URL;
};
var insertSortedValue = function insertSortedValue(fn) {
  return function (arr, value) {
    return [].concat(_toConsumableArray(arr.filter(function (n) {
      return !fn(n, value);
    })), [value], _toConsumableArray(arr.filter(function (n) {
      return fn(n, value);
    })));
  };
};
var serialize = function serialize(form) {
  return Array.from(new FormData(form), function (e) {
    return e.map(encodeURIComponent).join('=');
  }).join('&');
};
var getQueryValue = function getQueryValue(value) {
  return new URLSearchParams(window.location.search).get(value);
};
var asyncForEach = /*#__PURE__*/function () {
  var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(array, callback) {
    var index;
    return regeneratorRuntime.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            console.log(array, 'ok');
            index = 0;

          case 2:
            if (!(index < array.length)) {
              _context4.next = 8;
              break;
            }

            _context4.next = 5;
            return callback(array[index], index, array);

          case 5:
            index++;
            _context4.next = 2;
            break;

          case 8:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));

  return function asyncForEach(_x7, _x8) {
    return _ref8.apply(this, arguments);
  };
}();
var MONEY_FORMATS = {
  AMOUT: "${{amount}}",
  AMOUT_NO_DECIMALS: "${{amount_no_decimals}}"
}; // eslint-disable-next-line class-methods-use-this

var formatMoney = function formatMoney(cents) {
  var format = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : MONEY_FORMATS.AMOUT_NO_DECIMALS;
  if (typeof cents === "string") cents = cents.replace(".", "");
  var value = "";
  var placeholderRegex = /\{\{\s*(\w+)\s*\}\}/;
  var formatString = format;

  function formatWithDelimiters(number) {
    var precision = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;
    var thousands = arguments.length > 2 ? arguments[2] : undefined;
    var decimal = arguments.length > 3 ? arguments[3] : undefined;
    thousands = thousands || ",";
    decimal = decimal || ".";

    if (Number.isNaN(number) || number == null) {
      return 0;
    }

    number = (number / 100.0).toFixed(precision);
    var parts = number.split(".");
    var dollarsAmount = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "£1" + thousands);
    var centsAmount = parts[1] ? decimal + parts[1] : "";
    return dollarsAmount + centsAmount;
  }

  switch (formatString.match(placeholderRegex)[1]) {
    case "amount":
      value = formatWithDelimiters(cents, 2);
      break;

    case "amount_no_decimals":
      value = formatWithDelimiters(cents, 0);
      break;

    case "amount_with_comma_separator":
      value = formatWithDelimiters(cents, 2, ".", ",");
      break;

    case "amount_no_decimals_with_comma_separator":
      value = formatWithDelimiters(cents, 0, ".", ",");
      break;

    case "amount_no_decimals_with_space_separator":
      value = formatWithDelimiters(cents, 0, " ");
      break;

    default:
      value = formatWithDelimiters(cents, 2);
      break;
  }

  return formatString.replace(placeholderRegex, value);
}; // size is a number

var imageSize = function imageSize(src, size) {
  if (src.includes("cdn.accentuate")) {
    // if it is an accentuate image
    return "https://images.accentuate.io/?c_options=w_".concat(size, "&image=").concat(src);
  } else {
    // if shopify image
    var split = src.split(/\.(gif|jpe?g|png|bmp)/i);
    split.splice(1, 0, "_".concat(size, "x."));
    var newSrc = split.join("");
    return newSrc;
  }
};

/***/ }),

/***/ 403:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JoinForm", function() { return JoinForm; });
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var _lib_ajax_cart__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }



var JoinForm = /*#__PURE__*/function () {
  /**
   *
   */
  function JoinForm() {
    _classCallCheck(this, JoinForm);

    if (Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('.JoinForm')) {
      this.init();
    }
  }
  /**
   *
   */


  _createClass(JoinForm, [{
    key: "init",
    value: function init() {
      /**
       *
       * @param arr
       * @returns {*}
       */
      var sortArr = function sortArr(arr) {
        //Bubble to top based on model
        try {
          arr.forEach(function (item, i) {
            if (item.includes('XS') || item.includes('XR')) {
              arr.splice(i, 1);
              arr.unshift(item);
            }
          });
          arr.forEach(function (item, i) {
            if (item.includes('11')) {
              arr.splice(i, 1);
              arr.unshift(item);
            }
          });
          arr.forEach(function (item, i) {
            if (item.includes('12')) {
              arr.splice(i, 1);
              arr.unshift(item);
            }
          });
          arr.forEach(function (item, i) {
            if (item.endsWith('12')) {
              arr.splice(i, 1);
              arr.unshift(item);
            }
          });
          arr.forEach(function (item, i) {
            if (item.includes('13')) {
              arr.splice(i, 1);
              arr.unshift(item);
            }
          });
          arr.forEach(function (item, i) {
            if (item.endsWith('13')) {
              arr.splice(i, 1);
              arr.unshift(item);
            }
          }); // arr.forEach((item, i) => {
          //     if (item.includes('14')) {
          //         arr.splice(i, 1);
          //         arr.unshift(item);
          //     }
          // })
        } catch (error) {
          console.log(error);
        }

        return arr;
      };
      /**
       *
       * @constructor
       */


      var buildSelectOptions = function buildSelectOptions() {
        var options = '';
        options += "<option value=\"\">Select a device</option>";

        try {
          var phoneArr = Array.from(phoneModels);
          console.log(phoneArr);
          phoneArr.forEach(function (phone) {
            options += "<option value=\"".concat(phone, "\">").concat(phone, "</option>");
          });
        } catch (error) {
          console.log(error);
        }

        Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#phone_model').innerHTML = "".concat(options);
      };
      /**
       *
       * @constructor
       */


      var buildCaseTypeSelectOptions = function buildCaseTypeSelectOptions() {
        var phoneModel = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#phone_model');
        var currentPhoneModel = phoneModel.options[phoneModel.selectedIndex].value;
        Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#case_type').selectedIndex = 0;

        if (currentPhoneModel) {
          Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#case_type').disabled = false;
          var caseType = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#case_type');
          var caseTypes = [],
              options = '',
              hasOptions = false,
              activeOption = null;
          newCases.forEach(function (newCase, index) {
            var variants = newCase.variants;
            variants.forEach(function (variant, index) {
              if (variant.option1 == currentPhoneModel) {
                if (variant.option2 && !caseTypes.includes(variant.option2)) {
                  caseTypes.push(variant.option2);
                }
              } else if (variant.option2 == currentPhoneModel) {
                if (variant.option1 && !caseTypes.includes(variant.option1)) {
                  caseTypes.push(variant.option1);
                }
              }
            });
          });

          if (caseType.options.length > 0) {
            activeOption = caseType.options[caseType.selectedIndex].value;
            hasOptions = true;
          }

          options += "<option value=\"\">Select a case type</option>";
          caseTypes.forEach(function (ct) {
            options += "<option value=\"".concat(ct, "\">").concat(ct, "</option>");
          });
          var caseDrop = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#case_type');
          caseDrop.innerHTML = "".concat(options);
          var hasActiveOption = false;
          Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectArr */ "j"])('option', caseDrop).map(function (opt) {
            if (hasOptions && activeOption == opt.value) {
              hasActiveOption = true;
            }
          });

          if (!hasActiveOption) {
            activeOption = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('option', caseDrop).value;
          }

          caseDrop.value = activeOption;
        } else {
          Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#case_type').disabled = true;
          Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('.cs-join-club').disabled = true;
        }
      };
      /**
       * extract variants based on the product model and case type select
       * @constructor
       */


      var filterSelectedVariants = function filterSelectedVariants() {
        if (newCases.length > 0) {
          var data = [];
          var phoneModel = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#phone_model');
          var currentPhoneModel = phoneModel.options[phoneModel.selectedIndex].value;
          var caseType = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#case_type');
          var currentCaseType = caseType.options[caseType.selectedIndex].value;
          newCases.forEach(function (newCase, index) {
            var variants = newCase.variants;
            variants.forEach(function (variant, index) {
              if (variant.option1 == currentCaseType && variant.option2 == currentPhoneModel) {
                if (variant.inventory_quantity > 0) {
                  variant.product = newCase;
                  data.push(variant);
                }
              }
            });
          });
          renderCards(data);
        }
      };
      /**
       * select case
       */


      var initButtonsActions = function initButtonsActions() {
        Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectArr */ "j"])('.card-btn').map(function (btn) {
          Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* event */ "c"])(btn, 'click', function (e) {
            e.preventDefault();
            var oldActive = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('.card-btn-active');
            btn.innerText = 'SELECTED';
            Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* addClass */ "a"])(btn, 'card-btn-active');
            Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* removeClass */ "h"])(btn, 'card-btn');
            Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* addClass */ "a"])(btn.parentNode, 'highlighted');
            Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectArr */ "j"])('input[name="frequency"]').map(function (frequency) {
              frequency.disabled = false;
            });

            if (oldActive) {
              oldActive.innerText = 'SELECT';
              Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* removeClass */ "h"])(oldActive, 'card-btn-active');
              Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* addClass */ "a"])(oldActive, 'card-btn');
              Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* removeClass */ "h"])(oldActive.parentNode, 'highlighted');

              if (oldActive === btn) {
                Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectArr */ "j"])('input[name="frequency"]').map(function (frequency) {
                  frequency.checked = false;
                  frequency.disabled = true;
                  Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('.cs-join-club').disabled = true;
                });
              }
            }
          });
        });
      };
      /**
       * renders the cards from the data (filtered collection).
       * @param data
       */


      var renderCards = function renderCards(data) {
        var container = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#cases-grid');
        container.innerHTML = '';

        var filteredCases = _toConsumableArray(data);

        var filteredNewCases = [];

        if (filteredCases.length > 0) {
          //move club exclusives to front of list
          try {
            filteredCases.forEach(function (filteredcase, index) {
              if (filteredcase.product.tags.length > 0 && filteredcase.product.tags.includes('club-exclusive')) {
                filteredNewCases.push(filteredcase);
              }
            });
            filteredCases.forEach(function (filteredcase, index) {
              if (!(filteredcase.product.tags.length > 0 && filteredcase.product.tags.includes('club-exclusive'))) {
                filteredNewCases.push(filteredcase);
              }
            });
          } catch (error) {
            console.log(error);
          }

          if (filteredNewCases.length === filteredNewCases.length) {
            filteredCases = filteredNewCases;
          }

          var caseType = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#case_type'); //const currentCaseType = caseType.options[caseType.selectedIndex].value;

          var productCards = filteredCases.splice(0, 12).map(function (newCase, index) {
            var imageSrc = newCase.featured_image.src;
            var retail_price = (newCase.price / 100).toFixed(2);
            var saved_price = newCase.rcPrice.toFixed(2);
            var id = newCase.rcId;
            var title = newCase.product.title.split('|');
            var exclusive = newCase.product.tags.length > 0 && newCase.product.tags.includes('club-exclusive') ? '<div class="case-exclusive">CLUB EXCLUSIVE</div>' : '';
            var description = title[title.length - 1];
            return "<li class=\"card-card-wrap\">\n                                <div class=\"case-card\">\n                                    <div class=\"card-image\">\n                                        <img alt=\"\" src=\"".concat(imageSrc, "\"/>\n                                        <div class=\"hover\">\n                                            <img alt=\"\" src=\"").concat(imageSrc, "\"/>\n                                        </div>\n                                    </div>\n                                    <div class=\"case-title\">\n                                        ").concat(title[0], "\n                                    </div>\n                                    <div class=\"case-description\">\n                                         ").concat(description, "\n                                    </div>\n                                    <div class=\"case-price\">\n                                        <p class=\"saved\">$").concat(saved_price, "</p>\n                                        <p class=\"retail\">$").concat(retail_price, "</p>\n                                    </div> \n                                    ").concat(exclusive, "\n                                    <button class=\"btn card-btn\" data-product-id=\"").concat(id, "\">\n                                        SELECT\n                                    </button>\n                                </div>\n                            </li>");
          }).join('');

          if (container) {
            container.innerHTML = "".concat(productCards);
            Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#no-cases-to-show').style.display = 'none';
          }

          renderSurpriseCase();
        } else {
          container.innerHTML = "";
          Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#no-cases-to-show').style.display = 'flex';
          Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectArr */ "j"])('input[name="frequency"]').map(function (frequency) {
            frequency.checked = false;
            frequency.disabled = true;
            Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('.cs-join-club').disabled = true;
          });
        }
      };
      /**
       * renders a surprise case based on the collection
       */


      var renderSurpriseCase = function renderSurpriseCase() {
        var container = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#cases-grid');
        var phoneModel = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#phone_model');
        var currentPhoneModel = phoneModel.options[phoneModel.selectedIndex].value;
        var caseType = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#case_type');
        var currentCaseType = caseType.options[caseType.selectedIndex].value;

        if (surpriseMe[0]) {
          var product = surpriseMe[0];
          var variants = product.variants;
          var filteredVariant = variants.filter(function (variant) {
            return variant.option1 === currentCaseType && variant.option2 === currentPhoneModel;
          });

          if (!filteredVariant || filteredVariant.length < 1) {} else {
            var variant = filteredVariant[0];
            var variant_id = variant.rcId;
            var variant_price = variant.rcPrice.toFixed(2);

            if (container) {
              container.innerHTML += "<li class=\"card-card-wrap surprise\">\n                                                    <div class=\"case-card\">\n                                                        <div class=\"card-image\">\n                                                            <svg width=\"81\" height=\"80\" viewBox=\"0 0 81 80\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                                                                <mask id=\"rvp1d3tdua\" style=\"mask-type:alpha\" maskUnits=\"userSpaceOnUse\" x=\"0\" y=\"0\" width=\"81\" height=\"80\">\n                                                                    <path fill=\"#C4C4C4\" d=\"M.5 0h80v80H.5z\"/>\n                                                                </mask>\n                                                                <g mask=\"url(#rvp1d3tdua)\">\n                                                                    <path fill=\"#F46B6B\" d=\"M53.435 9.844h1.589v3.177h-1.589z\"/>\n                                                                    <rect x=\"35.916\" y=\"7.417\" width=\"19.152\" height=\"35.833\" rx=\"2.427\" fill=\"#DBEEDE\" stroke=\"#000\" stroke-width=\"1.5\"/>\n                                                                    <circle cx=\"39.167\" cy=\"10.667\" r=\"1.083\" fill=\"#4EA65E\" stroke=\"#000\" stroke-width=\".5\"/>\n                                                                    <circle cx=\"39.167\" cy=\"14.667\" r=\"1.083\" fill=\"#4EA65E\" stroke=\"#000\" stroke-width=\".5\"/>\n                                                                    <path fill=\"#4EA65E\" d=\"M36.5 21.334h18v18.667h-18z\"/>\n                                                                    <path stroke=\"#000\" stroke-width=\"1.5\" d=\"M55.167 20.75H36.5M55.167 39.417H36.5\"/>\n                                                                    <path d=\"m38.64 65.729-13.473-3.062-5.334-10c3.334-2.667 11.2-7.467 16-5.333 4.8 2.133 12.223 5.333 15.334 6.666.753.302 1.625.767 2.26 1.334l14.413-8.2a2.461 2.461 0 0 1 2.539 4.216L54.076 61.725a21.956 21.956 0 0 1-7.742 3.056l-5.297.994a5.908 5.908 0 0 1-2.398-.046z\" fill=\"#DBEEDE\"/>\n                                                                    <path d=\"m53.427 55.334 14.413-8.2a2.461 2.461 0 0 1 3.265.774v0a2.461 2.461 0 0 1-.726 3.442L54.076 61.725a21.956 21.956 0 0 1-7.742 3.056l-5.297.994a5.908 5.908 0 0 1-2.398-.046l-13.472-3.062-5.334-10c3.334-2.667 11.2-7.467 16-5.333 4.8 2.133 12.223 5.333 15.334 6.666 1.372.55 3.133 1.64 3.15 2.897.034 2.388-3.741 2.222-6.088 1.774-3.733-.713-8.003-1.611-8.396-2.004\" stroke=\"#000\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>\n                                                                    <mask id=\"jawa4gwonb\" fill=\"#fff\">\n                                                                        <rect x=\"8.5\" y=\"51.467\" width=\"10.667\" height=\"25.333\" rx=\"1.333\" transform=\"rotate(-26.746 8.5 51.467)\"/>\n                                                                    </mask>\n                                                                    <rect x=\"8.5\" y=\"51.467\" width=\"10.667\" height=\"25.333\" rx=\"1.333\" transform=\"rotate(-26.746 8.5 51.467)\" fill=\"#4EA65E\" stroke=\"#000\" stroke-width=\"3\" mask=\"url(#jawa4gwonb)\"/>\n                                                                </g>\n                                                            </svg>\n                                                        </div>\n                                                        <div class=\"case-title\">\n                                                            Surprise me\n                                                        </div>\n                                                        <div class=\"case-description\">\n                                                             We'll pick a case for you\n                                                        </div>\n                                                        <div class=\"case-price\">\n                                                            <p class=\"saved\">$".concat(variant_price, "</p>\n                                                        </div> \n                                                        <button class=\"btn card-btn\" data-product-id=\"").concat(variant_id, "\">\n                                                            SELECT\n                                                        </button>\n                                                    </div>\n                                                </li>");
            }
          }
        }
      };
      /**
       * phone model and case type change event listener
       */


      [Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#phone_model'), Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('#case_type')].map(function (el) {
        Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* event */ "c"])(el, 'change', function () {
          if (el.id.includes('phone_model')) {
            buildCaseTypeSelectOptions();
          }

          filterSelectedVariants();
          initButtonsActions();
        });
      });
      Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectArr */ "j"])('input[name="frequency"]').map(function (frequency) {
        Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* event */ "c"])(frequency, 'change', function () {
          Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('.cs-join-club').disabled = false;
        });
      });
      /**
       * join!
       */

      Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* event */ "c"])(Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('.cs-join-club'), 'click', function (e) {
        e.preventDefault();
        var selectedCase = Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('.card-btn-active');

        if (selectedCase) {
          var selectedId = selectedCase.getAttribute('data-product-id');

          if (selectedId) {
            var prop = {
              "shipping_interval_frequency": Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('input[name="frequency"]:checked').value,
              "shipping_interval_unit_type": "Months"
            };
            var data = {
              id: selectedId,
              quantity: 1,
              properties: {
                "shipping_interval_frequency": Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('input[name="frequency"]:checked').value,
                "shipping_interval_unit_type": "Months"
              }
            };
            Object(_lib_ajax_cart__WEBPACK_IMPORTED_MODULE_1__[/* addToCart */ "b"])(selectedId, 1, prop);
          } else {
            Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('.cs-join-club').innerText = 'PLEASE SELECT A CASE';
          }
        } else {
          Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* selectDoc */ "k"])('.cs-join-club').innerText = 'PLEASE SELECT A CASE';
        }
      });
      buildSelectOptions();
    }
  }]);

  return JoinForm;
}();
new JoinForm();

/***/ }),

/***/ 9:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return addToCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return addMultipleToCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return getCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return getCartToken; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return changeCart; });
/* unused harmony export updateCart */
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

var addToCart = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(id, quantity, properties) {
    var data,
        formData,
        res,
        _args = arguments;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            data = _args.length > 3 && _args[3] !== undefined ? _args[3] : {};
            formData = {
              id: id,
              quantity: quantity,
              properties: properties
            };
            _context.next = 4;
            return fetch("/cart/add.js", {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify(formData)
            }).then(function (response) {
              return response.json();
            }).then(function (json) {
              getCart();
              var cartEl = document.querySelector(".MiniCart");
              cartEl.classList.add("active");
            })["catch"](function (err) {
              /* uh oh, we have error. */
              console.error(err);
            });

          case 4:
            res = _context.sent;
            return _context.abrupt("return", res);

          case 6:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function addToCart(_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
}();
var addMultipleToCart = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(items) {
    var data,
        res,
        _args2 = arguments;
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            data = _args2.length > 1 && _args2[1] !== undefined ? _args2[1] : {};
            _context2.next = 3;
            return fetch("/cart/add.js", {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                items: items
              })
            }).then(function (response) {
              return response.json();
            }).then(function (json) {
              getCart();
              var cartEl = document.querySelector(".MiniCart");
              cartEl.classList.add("active");
            })["catch"](function (err) {
              /* uh oh, we have error. */
              console.error(err);
            });

          case 3:
            res = _context2.sent;
            return _context2.abrupt("return", res);

          case 5:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));

  return function addMultipleToCart(_x4) {
    return _ref2.apply(this, arguments);
  };
}(); // export const getCart = async () => {
//   const res = await fetch("/cart?view=compare", {
//     method: 'GET'
//   })
//   .then(function (response) {
//     return response.text();
//   })  
//   .then(html => {
//     // Here, you have the HTML result
//     var temp = document.createElement('div');
//     temp.innerHTML = html;
//     let test = temp.querySelector('.shopify-section').innerHTML;
//     return JSON.parse(test);
//   })
//   .catch(function (err){
//     console.log(err, 'getcart')
//   });
//   var event = new CustomEvent("cartUpdated", { detail: res });
//   document.dispatchEvent(event);
//   return res;
// }

var getCart = /*#__PURE__*/function () {
  var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
    var res, event;
    return regeneratorRuntime.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return fetch("/cart.js", {
              method: 'GET',
              headers: {
                'Content-Type': 'application/json'
              }
            }).then(function (response) {
              return response.json();
            })["catch"](function (err) {
              console.log(err, 'getcart');
            });

          case 2:
            res = _context3.sent;
            event = new CustomEvent("cartUpdated", {
              detail: res
            });
            document.dispatchEvent(event);
            return _context3.abrupt("return", res);

          case 6:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));

  return function getCart() {
    return _ref3.apply(this, arguments);
  };
}();
var getCartToken = /*#__PURE__*/function () {
  var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
    var res;
    return regeneratorRuntime.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return fetch("/cart.js", {
              method: 'GET',
              headers: {
                'Content-Type': 'application/json'
              }
            }).then(function (response) {
              return response.json();
            })["catch"](function (err) {
              console.log(err, 'getcart');
            });

          case 2:
            res = _context4.sent;
            return _context4.abrupt("return", res.token);

          case 4:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));

  return function getCartToken() {
    return _ref4.apply(this, arguments);
  };
}();
var changeCart = function changeCart(id, quantity) {
  var formData = {
    "id": "".concat(id),
    quantity: quantity
  };
  return fetch("/cart/change.js", {
    method: 'POST',
    credentials: 'same-origin',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(formData)
  }).then(function (res) {
    return res;
  });
};
var updateCart = /*#__PURE__*/function () {
  var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(id, quantity) {
    var data,
        serializeExist,
        content,
        formData,
        res,
        _args5 = arguments;
    return regeneratorRuntime.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            data = _args5.length > 2 && _args5[2] !== undefined ? _args5[2] : {};
            serializeExist = _args5.length > 3 ? _args5[3] : undefined;
            content = _args5.length > 4 ? _args5[4] : undefined;
            formData = {
              id: id,
              quantity: quantity
            };
            res = fetch("/cart/update.js", {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify(formData)
            }).then(function (response) {
              return response.json();
            }).then(function (json) {})["catch"](function (err) {
              /* uh oh, we have error. */
              console.error(err, 'update');
            });
            return _context5.abrupt("return", res);

          case 6:
          case "end":
            return _context5.stop();
        }
      }
    }, _callee5);
  }));

  return function updateCart(_x5, _x6) {
    return _ref5.apply(this, arguments);
  };
}();

/***/ })

/******/ });
//# sourceMappingURL=component.joinForm.js.map