/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 99);
/******/ })
/************************************************************************/
/******/ ({

/***/ 99:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var Navigation = /*#__PURE__*/function () {
  function Navigation(element) {
    _classCallCheck(this, Navigation);

    this.element = element;
    this.promoElHeight = element.closest('.section-header').querySelector('.js-promo').offsetHeight;
    this.init();
  }

  _createClass(Navigation, [{
    key: "getElement",
    value: function getElement() {
      return this.element;
    }
  }, {
    key: "getHoverItems",
    value: function getHoverItems() {
      var element = this.getElement();
      return element.querySelectorAll('.js-hover');
    }
  }, {
    key: "getHoverSub",
    value: function getHoverSub() {
      var element = this.getElement();
      return element.querySelectorAll('.js-subHover');
    }
  }, {
    key: "getPromobar",
    value: function getPromobar() {
      var element = this.getElement();
      return element.closest('.section-header').querySelector('.js-promo');
    }
  }, {
    key: "getMobileMenu",
    value: function getMobileMenu() {
      var element = this.getElement();
      return element.closest('.section-header').querySelector('.js-menu');
    }
  }, {
    key: "getSubMenu",
    value: function getSubMenu() {
      var menuEl = this.getMobileMenu();
      return menuEl.querySelectorAll('.js-sideDrawer');
    }
  }, {
    key: "getOverlay",
    value: function getOverlay() {
      var element = this.getElement();
      return element.querySelector('.js-overlay');
    }
  }, {
    key: "showOverlay",
    value: function showOverlay() {
      var overlayEl = this.getOverlay();
      overlayEl.classList.add('active');
    }
  }, {
    key: "removeOverlay",
    value: function removeOverlay() {
      var overlayEl = this.getOverlay();
      overlayEl.classList.remove('active');
    }
  }, {
    key: "showBorder",
    value: function showBorder() {
      var scrolled = document.scrollingElement.scrollTop;
      var headerEl = this.getElement();
      scrolled < 1 ? headerEl.classList.add('scrolled') : null;
    }
  }, {
    key: "removeBorder",
    value: function removeBorder() {
      var scrolled = document.scrollingElement.scrollTop;
      var headerEl = this.getElement();
      scrolled < 1 ? headerEl.classList.remove('scrolled') : null;
    }
  }, {
    key: "getBody",
    value: function getBody() {
      var element = this.getElement();
      return element.closest('body');
    }
  }, {
    key: "getHtml",
    value: function getHtml() {
      var element = this.getElement();
      return element.closest('html');
    }
  }, {
    key: "freezeBody",
    value: function freezeBody() {
      var htmlEl = this.getHtml();
      htmlEl.style.overflow = 'hidden';
      htmlEl.style.overflow = 'clip';
    }
  }, {
    key: "unfreezeBody",
    value: function unfreezeBody() {
      var htmlEl = this.getHtml();
      htmlEl.style.overflow = null;
    }
  }, {
    key: "setHover",
    value: function setHover() {
      var _this = this;

      var hoverEl = this.getHoverItems();

      var _iterator = _createForOfIteratorHelper(hoverEl),
          _step;

      try {
        var _loop = function _loop() {
          var hover = _step.value;
          hover.addEventListener('mouseover', function () {
            var hasChild = hover.classList.contains('js-hasChild');

            if (hasChild) {
              hover.closest('.Nav__left').classList.add('active');
              hover.closest('.Nav__left').classList.add('slide-in');
              hover.classList.add('active');

              _this.showOverlay();

              _this.showBorder();

              _this.freezeBody();
            }
          });
          hover.addEventListener('mouseleave', function () {
            hover.classList.remove('active');
            hover.closest('.Nav__left').classList.remove('active');
            hover.closest('.Nav__left').classList.remove('slide-in');

            _this.removeOverlay();

            _this.removeBorder();

            _this.unfreezeBody();
          });
        };

        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          _loop();
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
  }, {
    key: "setGrandHover",
    value: function setGrandHover() {
      var grandEl = this.getHoverSub();

      var _iterator2 = _createForOfIteratorHelper(grandEl),
          _step2;

      try {
        var _loop2 = function _loop2() {
          var grand = _step2.value;
          grand.addEventListener('mouseover', function () {
            var hasGrand = grand.classList.contains('js-grandChild');

            if (hasGrand) {
              grand.closest('.Nav__side-menu--container').classList.add('active');
              grand.closest('.Nav__side-menu--container').classList.add('slide-in');
              grand.classList.add('active');
            }
          });
          grand.addEventListener('mouseleave', function () {
            grand.classList.remove('active');
            grand.closest('.Nav__side-menu--container').classList.remove('active');
            grand.closest('.Nav__side-menu--container').classList.remove('slide-in');
          });
        };

        for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
          _loop2();
        }
      } catch (err) {
        _iterator2.e(err);
      } finally {
        _iterator2.f();
      }
    }
  }, {
    key: "setClosePromo",
    value: function setClosePromo() {
      var _this2 = this;

      try {
        var promoEl = this.getPromobar();
        var promoClose = promoEl.querySelector('.js-promoClose');
        var sideMenu = this.element.querySelectorAll('.js-sideMenu');
        var mobileMenu = this.getMobileMenu();
        var subMenuEl = this.getSubMenu();
        promoClose.addEventListener('click', function () {
          promoEl.style.display = 'none';
          _this2.promoElHeight = promoEl.offsetHeight;
          mobileMenu.style.setProperty('height', 'calc(100vh - 60px)');

          var _iterator3 = _createForOfIteratorHelper(subMenuEl),
              _step3;

          try {
            for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
              var subMenu = _step3.value;
              subMenu.style.setProperty('height', "calc(100vh - ".concat(_this2.promoElHeight, "px - 60px)"));
              subMenu.style.setProperty('top', "calc(60px + ".concat(_this2.promoElHeight, "px)"));
            }
          } catch (err) {
            _iterator3.e(err);
          } finally {
            _iterator3.f();
          }

          var _iterator4 = _createForOfIteratorHelper(sideMenu),
              _step4;

          try {
            for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
              var side = _step4.value;
              side.style.top = 70 + 'px';
            }
          } catch (err) {
            _iterator4.e(err);
          } finally {
            _iterator4.f();
          }
        });
      } catch (_unused) {}
    }
  }, {
    key: "setResize",
    value: function setResize() {
      var _this3 = this;

      var promobarEl = this.getPromobar();
      var sideMenu = this.element.querySelectorAll('.js-sideMenu');

      function debounce(func) {
        var timer;
        return function (event) {
          if (timer) clearTimeout(timer);
          timer = setTimeout(func, 100, event);
        };
      }

      window.addEventListener("resize", debounce(function () {
        _this3.promoElHeight = promobarEl.offsetHeight;

        var _iterator5 = _createForOfIteratorHelper(sideMenu),
            _step5;

        try {
          for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
            var side = _step5.value;
            side.style.top = _this3.promoElHeight + 70 + 'px';
          }
        } catch (err) {
          _iterator5.e(err);
        } finally {
          _iterator5.f();
        }
      }));
    }
  }, {
    key: "setSideNav",
    value: function setSideNav() {
      var sideMenu = this.element.querySelectorAll('.js-sideMenu');

      var _iterator6 = _createForOfIteratorHelper(sideMenu),
          _step6;

      try {
        for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
          var side = _step6.value;
          side.style.top = this.promoElHeight + 70 + 'px';
        }
      } catch (err) {
        _iterator6.e(err);
      } finally {
        _iterator6.f();
      }
    }
  }, {
    key: "setScroll",
    value: function setScroll() {
      var _this4 = this;

      var prevScrollpos = window.pageYOffset;
      var headerEl = this.getElement().closest('.section-header');
      var htmlEl = this.getHtml().dataset.popupExist;

      window.onscroll = function () {
        var currentScrollPos = window.pageYOffset;

        if (prevScrollpos > currentScrollPos) {
          headerEl.classList.add('show');
          headerEl.style.top = 0;
        } else {
          headerEl.classList.remove('show');
          headerEl.style.top = -_this4.promoElHeight + -70 + 'px';
        }

        prevScrollpos = currentScrollPos;
      };
    }
  }, {
    key: "setMobileHeight",
    value: function setMobileHeight() {
      var mobileMenu = this.getMobileMenu();
      mobileMenu.style.setProperty('height', "calc(100vh - ".concat(this.promoElHeight, "px - 60px)"));
    }
  }, {
    key: "setSubMenuHeight",
    value: function setSubMenuHeight() {
      var subMenuEl = this.getSubMenu();

      var _iterator7 = _createForOfIteratorHelper(subMenuEl),
          _step7;

      try {
        for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
          var subMenu = _step7.value;
          subMenu.style.setProperty('height', "calc(100vh - ".concat(this.promoElHeight, "px - 60px)"));
          subMenu.style.setProperty('top', "calc(60px + ".concat(this.promoElHeight, "px)"));
        }
      } catch (err) {
        _iterator7.e(err);
      } finally {
        _iterator7.f();
      }
    }
  }, {
    key: "setEventHandlers",
    value: function setEventHandlers() {
      this.setHover();
      this.setGrandHover(); // this.setScroll();

      this.setClosePromo();
      this.setResize();
      this.setSideNav();
      this.setMobileHeight(); // this.setSubMenuHeight();
    }
  }, {
    key: "init",
    value: function init() {
      this.setEventHandlers();
    }
  }]);

  return Navigation;
}();

var NavigationInit = {
  init: function init() {
    var $el = document.querySelector("header");

    if ($el) {
      new Navigation($el);
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (NavigationInit);

/***/ })

/******/ });
//# sourceMappingURL=component.navigation.js.map