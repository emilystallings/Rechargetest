/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 405);
/******/ })
/************************************************************************/
/******/ ({

/***/ 405:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var Login = /*#__PURE__*/function () {
  function Login(element) {
    _classCallCheck(this, Login);

    this.element = element;
    this.formComponents = {
      CustomerEmail: false,
      CustomerPassword: false
    };
    this.init();
  }

  _createClass(Login, [{
    key: "getElement",
    value: function getElement() {
      return this.element;
    }
  }, {
    key: "getFormComponents",
    value: function getFormComponents() {
      return this.formComponents;
    }
  }, {
    key: "setButtons",
    value: function setButtons() {
      var element = this.getElement();
      var CustomerEmail = element.querySelector('#CustomerEmail');
      var CustomerPassword = element.querySelector('#CustomerPassword');
      CustomerEmail.addEventListener("input", this.handleInputChange.bind(this));
      CustomerPassword.addEventListener("input", this.handleInputChange.bind(this));
    }
  }, {
    key: "handleInputChange",
    value: function handleInputChange(e) {
      var formComponents = this.getFormComponents();
      var element = this.getElement();
      var SignIn = element.querySelector('.SignIn');
      formComponents[e.currentTarget.id] = e.currentTarget.value.length > 0;

      if (formComponents.CustomerEmail && formComponents.CustomerPassword) {
        SignIn.removeAttribute('disabled');
        SignIn.classList.add('btn-blue');
        SignIn.classList.remove('btn-gray');
      } else {
        SignIn.setAttribute('disabled', true);
        SignIn.classList.remove('btn-blue');
        SignIn.classList.add('btn-gray');
      }
    }
  }, {
    key: "setForms",
    value: function setForms() {
      var element = this.getElement();
      var RecoverPasswordBtn = element.querySelector('#RecoverPassword');
      var HideRecoverPasswordBtn = element.querySelector('#HideRecoverPasswordLink');
      RecoverPasswordBtn.addEventListener("click", this.handleFormChange.bind(this));
      HideRecoverPasswordBtn.addEventListener("click", this.handleFormChange.bind(this));
    }
  }, {
    key: "handleFormChange",
    value: function handleFormChange(e) {
      var element = this.getElement();
      var CustomerLoginForm = element.querySelector('#CustomerLoginForm');
      var RecoverPasswordForm = element.querySelector('#RecoverPasswordForm');

      if (e.currentTarget.id === 'RecoverPassword') {
        CustomerLoginForm.classList.add('hide');
        RecoverPasswordForm.classList.remove('hide');
      } else {
        CustomerLoginForm.classList.remove('hide');
        RecoverPasswordForm.classList.add('hide');
      }
    }
  }, {
    key: "setEventHandlers",
    value: function setEventHandlers() {
      try {
        this.setButtons();
        this.setForms();
      } catch (_unused) {}
    }
  }, {
    key: "init",
    value: function init() {
      this.setEventHandlers();
    }
  }]);

  return Login;
}();

var LoginInit = {
  init: function init() {
    var $el = document.querySelector(".Login");

    if ($el) {
      new Login($el);
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (LoginInit);
LoginInit.init();

/***/ })

/******/ });
//# sourceMappingURL=component.login.js.map