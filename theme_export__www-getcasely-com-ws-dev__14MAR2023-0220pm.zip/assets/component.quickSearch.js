/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 98);
/******/ })
/************************************************************************/
/******/ ({

/***/ 98:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var SearchButton = /*#__PURE__*/function () {
  function SearchButton(element) {
    _classCallCheck(this, SearchButton);

    this.element = element;
    this.init();
  }

  _createClass(SearchButton, [{
    key: "getElement",
    value: function getElement() {
      return this.element;
    }
  }, {
    key: "getHTML",
    value: function getHTML() {
      var element = this.getElement();
      return element.closest('html');
    }
  }, {
    key: "getButton",
    value: function getButton() {
      var element = this.getElement();
      return element.querySelectorAll('.js-searchButton');
    }
  }, {
    key: "getPredictiveSearch",
    value: function getPredictiveSearch() {
      var element = this.getElement();
      return element.querySelector('.js-predictiveSearch');
    }
  }, {
    key: "getResultsContainer",
    value: function getResultsContainer() {
      var element = this.getElement();
      return element.querySelector('.js-searchResults');
    }
  }, {
    key: "getClose",
    value: function getClose() {
      var element = this.getElement();
      return element.querySelectorAll('.js-closeSearch');
    }
  }, {
    key: "getOverlay",
    value: function getOverlay() {
      var element = this.getElement();
      return element.querySelector('.js-overlay');
    }
  }, {
    key: "getInput",
    value: function getInput() {
      var element = this.getElement();
      return element.querySelector('.js-searchInput');
    }
  }, {
    key: "setOverlay",
    value: function setOverlay() {
      var overlayEl = this.getOverlay();
      overlayEl.classList.add('active-search');
    }
  }, {
    key: "removeOverlay",
    value: function removeOverlay() {
      var overlayEl = this.getOverlay();
      overlayEl.classList.remove('active-search');
    }
  }, {
    key: "setClose",
    value: function setClose() {
      var _this = this;

      var closeEl = this.getClose();
      var searchEl = this.getPredictiveSearch();
      var resultContainerEl = this.getResultsContainer();
      var htmlEl = this.getHTML();
      var overlayEl = this.getOverlay();
      var inputEl = this.getInput();

      var _iterator = _createForOfIteratorHelper(closeEl),
          _step;

      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var close = _step.value;
          close.addEventListener('click', function () {
            searchEl.classList.remove('active');
            resultContainerEl.style.display = 'none';
            htmlEl.style.overflow = 'unset';

            _this.removeOverlay();

            inputEl.value = '';

            _this.hideUnderline();
          });
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
  }, {
    key: "showUnderline",
    value: function showUnderline() {
      var buttonEl = this.getButton();

      var _iterator2 = _createForOfIteratorHelper(buttonEl),
          _step2;

      try {
        for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
          var button = _step2.value;
          button.classList.add('active');
        }
      } catch (err) {
        _iterator2.e(err);
      } finally {
        _iterator2.f();
      }
    }
  }, {
    key: "hideUnderline",
    value: function hideUnderline() {
      var buttonEl = this.getButton();

      var _iterator3 = _createForOfIteratorHelper(buttonEl),
          _step3;

      try {
        for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
          var button = _step3.value;
          button.classList.remove('active');
        }
      } catch (err) {
        _iterator3.e(err);
      } finally {
        _iterator3.f();
      }
    }
  }, {
    key: "setButton",
    value: function setButton() {
      var _this2 = this;

      var buttonEl = this.getButton();
      var searchEl = this.getPredictiveSearch();
      var htmlEl = this.getHTML();
      var overlayEl = this.getOverlay();
      var inputEl = this.getInput();

      var _iterator4 = _createForOfIteratorHelper(buttonEl),
          _step4;

      try {
        for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
          var button = _step4.value;
          button.addEventListener('click', function (event) {
            event.preventDefault();
            searchEl.classList.add('active');
            htmlEl.style.overflow = 'hidden';

            _this2.setOverlay();

            inputEl.focus();

            _this2.showUnderline();
          });
        }
      } catch (err) {
        _iterator4.e(err);
      } finally {
        _iterator4.f();
      }
    }
  }, {
    key: "setEventHandlers",
    value: function setEventHandlers() {
      this.setClose();
      this.setButton();
    }
  }, {
    key: "init",
    value: function init() {
      this.setEventHandlers();
    }
  }]);

  return SearchButton;
}();

var SearchButtonInit = {
  init: function init() {
    var $el = document.querySelector(".js-header");

    if ($el) {
      new SearchButton($el);
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (SearchButtonInit);

/***/ })

/******/ });
//# sourceMappingURL=component.quickSearch.js.map