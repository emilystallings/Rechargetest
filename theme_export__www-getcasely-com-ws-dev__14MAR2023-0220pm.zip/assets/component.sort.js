/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 419);
/******/ })
/************************************************************************/
/******/ ({

/***/ 1:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export pipe */
/* unused harmony export compose */
/* unused harmony export map */
/* unused harmony export filter */
/* unused harmony export pluck */
/* unused harmony export sort */
/* unused harmony export mapDOMElements */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return selectAll; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return selectArr; });
/* unused harmony export select */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return selectDoc; });
/* unused harmony export value */
/* unused harmony export getElems */
/* unused harmony export dataValue */
/* unused harmony export removeAttribute */
/* unused harmony export closest */
/* unused harmony export remove */
/* unused harmony export nextSibling */
/* unused harmony export prevSibling */
/* unused harmony export toggleAttr */
/* unused harmony export setAttr */
/* unused harmony export getAttr */
/* unused harmony export submit */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "l", function() { return toggleClass; });
/* unused harmony export setText */
/* unused harmony export setHtml */
/* unused harmony export opacity */
/* unused harmony export styles */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return hasClass; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return isVisible; });
/* unused harmony export removeClassAll */
/* unused harmony export addClassAll */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return addClass; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return removeClass; });
/* unused harmony export toggleClassAll */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return event; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return ajax; });
/* unused harmony export observeAdd */
/* unused harmony export observeRemove */
/* unused harmony export cartesian */
/* unused harmony export count */
/* unused harmony export goTo */
/* unused harmony export insertSortedValue */
/* unused harmony export serialize */
/* unused harmony export getQueryValue */
/* unused harmony export asyncForEach */
/* unused harmony export MONEY_FORMATS */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return formatMoney; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return imageSize; });
function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e2) { throw _e2; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e3) { didErr = true; err = _e3; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/*
  The purpose of this file is generate/introduce a toolbelt (Similar to loadash, Ramda, RxJS)
  following the DRY principle and functional programming practices
*/

/*
 Composition functions
*/

/*
  Pipe is a function to create composition of functions (using map, filter, sort, etc)
  Usage example: https://www.freecodecamp.org/news/pipe-and-compose-in-javascript-5b04004ac937/
  External resources: https://medium.com/javascript-scene/tagged/functional-programming
*/
var pipe = function pipe() {
  for (var _len = arguments.length, fns = new Array(_len), _key = 0; _key < _len; _key++) {
    fns[_key] = arguments[_key];
  }

  return function (x) {
    return fns.reduce(function (v, f) {
      return f(v);
    }, x);
  };
};
var compose = function compose() {
  for (var _len2 = arguments.length, fns = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    fns[_key2] = arguments[_key2];
  }

  return function (x) {
    return fns.reduceRight(function (v, f) {
      return f(v);
    }, x);
  };
};
var map = function map(f) {
  return function (arr) {
    return arr.reduce(function (acc, x) {
      return [].concat(_toConsumableArray(acc), [f(x)]);
    }, []);
  };
};
var filter = function filter(f) {
  return function (arr) {
    return arr.reduce(function (acc, x) {
      return f(x) ? [].concat(_toConsumableArray(acc), [x]) : acc;
    }, []);
  };
};
var pluck = function pluck(str) {
  return function (arr) {
    return arr.reduce(function (acc, x) {
      return [].concat(_toConsumableArray(acc), [_defineProperty({}, str, x[str])]);
    }, []);
  };
};
var sort = function sort(fn) {
  return function (arr) {
    return arr.reduce(insertSortedValue(fn), []);
  };
};
/*
  General DOM functions
  Use these functions to select, handle html elements (similar to jQuery)
*/
//Apply/Loop function to a group of html elements

var mapDOMElements = function mapDOMElements(fn) {
  return function (items) {
    return _toConsumableArray(items).forEach(fn);
  };
};
var selectAll = function selectAll(query) {
  var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return item.querySelectorAll(query);
};
var selectArr = function selectArr(query) {
  var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return [].slice.call(item.querySelectorAll(query));
};
var select = function select() {
  var item = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : document;
  var query = arguments.length > 1 ? arguments[1] : undefined;
  return item.querySelector(query);
};
var selectDoc = function selectDoc(query) {
  var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return item.querySelector(query);
};
var value = function value(query) {
  var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return item.querySelector(query).value;
}; //General query for elements equivalent to $()

var getElems = function getElems(query) {
  var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return _toConsumableArray(item.querySelectorAll(query));
};
var dataValue = function dataValue(_ref2) {
  var dataset = _ref2.dataset;
  return function (id) {
    return dataset[id];
  };
};
/*
  General DOM functions
  Use these functions to update html elements (similar to jQuery)
*/

var removeAttribute = function removeAttribute(tag) {
  return function (item) {
    return item.removeAttribute(tag);
  };
};
var closest = function closest(item) {
  return function (query) {
    return item.closest(query);
  };
};
var remove = function remove(item) {
  return item.parentNode.removeChild(item);
};
var nextSibling = function nextSibling(item) {
  return item.nextElementSibling;
};
var prevSibling = function prevSibling(item) {
  return item.previousElementSibling;
};
var toggleAttr = function toggleAttr(item, attr) {
  return item.toggleAttribute(attr);
};
var setAttr = function setAttr(attr, value) {
  return function (item) {
    return item.setAttribute(attr, value);
  };
};
var getAttr = function getAttr(attr) {
  return function (item) {
    return item.getAttribute(attr);
  };
};
var submit = function submit(item) {
  return item.submit(item);
};
var toggleClass = function toggleClass(item, cls) {
  return item.classList.toggle(cls);
};
var setText = function setText(item) {
  return function (text) {
    return item.innerText = text;
  };
};
var setHtml = function setHtml(item) {
  return function (html) {
    return item.innerHTML = html;
  };
};
var opacity = function opacity(value) {
  return function (item) {
    return item.style.opacity = "".concat(value);
  };
};
var styles = function styles(elem, _styles) {
  return elem.setAttribute("style", Object.entries(_styles).map(function (_ref3) {
    var _ref4 = _slicedToArray(_ref3, 2),
        key = _ref4[0],
        value = _ref4[1];

    return "".concat(key, ": ").concat(value, ";");
  }).join(' '));
};
/*
jpgg
*/

var hasClass = function hasClass(target, className) {
  return new RegExp('(\\s|^)' + className + '(\\s|$)').test(target.className);
};
var isVisible = function isVisible(elem) {
  return !!elem && !!(elem.offsetWidth || elem.offsetHeight || elem.getClientRects().length);
}; // source (2018-03-11): https://github.com/jquery/jquery/blob/master/src/css/hiddenVisibleSelectors.js

var removeClassAll = function removeClassAll(list, cls) {
  return list.map(function (l) {
    return l.classList.remove(cls);
  });
};
var addClassAll = function addClassAll(list, cls) {
  return list.map(function (l) {
    return l.classList.add(cls);
  });
};
var addClass = function addClass(e, cls) {
  return !hasClass(e, cls) ? e.classList.add(cls) : false;
};
var removeClass = function removeClass(e, cls) {
  return hasClass(e, cls) ? e.classList.remove(cls) : false;
};
var toggleClassAll = function toggleClassAll(items, cls) {
  return [].slice.call(items).map(function (item) {
    return item.classList.toggle(cls);
  });
};
var event = function event(elem, _event, func) {
  return elem ? elem.addEventListener(_event, func) : console.log('Invalid element to apply ' + _event + ': ' + func);
};
var ajax = /*#__PURE__*/function () {
  var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(method, url) {
    var data,
        contentType,
        xhttp,
        _args = arguments;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            data = _args.length > 2 && _args[2] !== undefined ? _args[2] : {};
            contentType = _args.length > 3 && _args[3] !== undefined ? _args[3] : 'application/json';
            xhttp = _args.length > 4 && _args[4] !== undefined ? _args[4] : null;
            return _context.abrupt("return", new Promise(function (resolve) {
              if (!xhttp) {
                xhttp = new XMLHttpRequest();
              }

              xhttp.onreadystatechange = function () {
                if (xhttp.readyState === 4) {
                  resolve(JSON.stringify({
                    status: xhttp.status,
                    response: xhttp.responseText
                  }));
                }
              };

              xhttp.open(method, url, true);

              if (method === 'POST' && data) {
                xhttp.setRequestHeader('Content-type', contentType);
                xhttp.send(data);
              } else {
                xhttp.send();
              }

              return xhttp;
            }));

          case 4:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function ajax(_x, _x2) {
    return _ref5.apply(this, arguments);
  };
}();
var observeAdd = /*#__PURE__*/function () {
  var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(container, callback) {
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            new MutationObserver(function (mutationsList, observer) {
              var _iterator = _createForOfIteratorHelper(mutationsList),
                  _step;

              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var mutation = _step.value;

                  if (mutation.type === 'childList') {
                    var nodes = [].slice.call(mutation.addedNodes);

                    if (nodes.length > 0) {
                      callback(nodes);
                    }
                  }
                }
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
            }).observe(container, {
              attributes: true,
              childList: true,
              subtree: true
            });

          case 1:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));

  return function observeAdd(_x3, _x4) {
    return _ref6.apply(this, arguments);
  };
}();
var observeRemove = /*#__PURE__*/function () {
  var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(container, callback) {
    return regeneratorRuntime.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            new MutationObserver(function (mutationsList, observer) {
              var _iterator2 = _createForOfIteratorHelper(mutationsList),
                  _step2;

              try {
                for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                  var mutation = _step2.value;

                  if (mutation.type === 'childList') {
                    var nodes = [].slice.call(mutation.removedNodes);

                    if (nodes.length > 0) {
                      callback(nodes);
                    }
                  }
                }
              } catch (err) {
                _iterator2.e(err);
              } finally {
                _iterator2.f();
              }
            }).observe(container, {
              attributes: true,
              childList: true,
              subtree: true
            });

          case 1:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));

  return function observeRemove(_x5, _x6) {
    return _ref7.apply(this, arguments);
  };
}();
var cartesian = function cartesian() {
  for (var _len3 = arguments.length, a = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
    a[_key3] = arguments[_key3];
  }

  return a.reduce(function (a, b) {
    return a.flatMap(function (d) {
      return b.map(function (e) {
        return [d, e].flat();
      });
    });
  });
};
/*
  General purpose functions
  Use these functions to apply certain operation in your context
*/

var count = function count(str) {
  return str.length;
};
var goTo = function goTo(URL) {
  return window.location.href = URL;
};
var insertSortedValue = function insertSortedValue(fn) {
  return function (arr, value) {
    return [].concat(_toConsumableArray(arr.filter(function (n) {
      return !fn(n, value);
    })), [value], _toConsumableArray(arr.filter(function (n) {
      return fn(n, value);
    })));
  };
};
var serialize = function serialize(form) {
  return Array.from(new FormData(form), function (e) {
    return e.map(encodeURIComponent).join('=');
  }).join('&');
};
var getQueryValue = function getQueryValue(value) {
  return new URLSearchParams(window.location.search).get(value);
};
var asyncForEach = /*#__PURE__*/function () {
  var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(array, callback) {
    var index;
    return regeneratorRuntime.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            console.log(array, 'ok');
            index = 0;

          case 2:
            if (!(index < array.length)) {
              _context4.next = 8;
              break;
            }

            _context4.next = 5;
            return callback(array[index], index, array);

          case 5:
            index++;
            _context4.next = 2;
            break;

          case 8:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));

  return function asyncForEach(_x7, _x8) {
    return _ref8.apply(this, arguments);
  };
}();
var MONEY_FORMATS = {
  AMOUT: "${{amount}}",
  AMOUT_NO_DECIMALS: "${{amount_no_decimals}}"
}; // eslint-disable-next-line class-methods-use-this

var formatMoney = function formatMoney(cents) {
  var format = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : MONEY_FORMATS.AMOUT_NO_DECIMALS;
  if (typeof cents === "string") cents = cents.replace(".", "");
  var value = "";
  var placeholderRegex = /\{\{\s*(\w+)\s*\}\}/;
  var formatString = format;

  function formatWithDelimiters(number) {
    var precision = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;
    var thousands = arguments.length > 2 ? arguments[2] : undefined;
    var decimal = arguments.length > 3 ? arguments[3] : undefined;
    thousands = thousands || ",";
    decimal = decimal || ".";

    if (Number.isNaN(number) || number == null) {
      return 0;
    }

    number = (number / 100.0).toFixed(precision);
    var parts = number.split(".");
    var dollarsAmount = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "£1" + thousands);
    var centsAmount = parts[1] ? decimal + parts[1] : "";
    return dollarsAmount + centsAmount;
  }

  switch (formatString.match(placeholderRegex)[1]) {
    case "amount":
      value = formatWithDelimiters(cents, 2);
      break;

    case "amount_no_decimals":
      value = formatWithDelimiters(cents, 0);
      break;

    case "amount_with_comma_separator":
      value = formatWithDelimiters(cents, 2, ".", ",");
      break;

    case "amount_no_decimals_with_comma_separator":
      value = formatWithDelimiters(cents, 0, ".", ",");
      break;

    case "amount_no_decimals_with_space_separator":
      value = formatWithDelimiters(cents, 0, " ");
      break;

    default:
      value = formatWithDelimiters(cents, 2);
      break;
  }

  return formatString.replace(placeholderRegex, value);
}; // size is a number

var imageSize = function imageSize(src, size) {
  if (src.includes("cdn.accentuate")) {
    // if it is an accentuate image
    return "https://images.accentuate.io/?c_options=w_".concat(size, "&image=").concat(src);
  } else {
    // if shopify image
    var split = src.split(/\.(gif|jpe?g|png|bmp)/i);
    split.splice(1, 0, "_".concat(size, "x."));
    var newSrc = split.join("");
    return newSrc;
  }
};

/***/ }),

/***/ 12:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export addCartItem */
/* unused harmony export addCartItemData */
/* unused harmony export removeCartItem */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return formatMoney; });
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var _service_event_bus__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
/*
*
* Shopify API cart methods
*
* */


/**
 *
 * Add to cart single item
 *
 * @param id
 * @param quantity
 * @returns {Promise<*|undefined>}
 */

var addCartItem = function addCartItem(id) {
  var quantity = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;

  try {
    return new Promise(function (resolve) {
      _service_event_bus__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dispatch(_service_event_bus__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].types.AddingToCart);
      Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* ajax */ "b"])("POST", "/cart/add.js", JSON.stringify({
        quantity: quantity,
        id: parseInt(id)
      })).then(function (response) {
        resolve(response);
        _service_event_bus__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dispatch(_service_event_bus__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].types.AddedToCart, response);
      });
    });
  } catch (e) {
    console.log("Error adding to cart.", e);
  }
};
/**
 *
 * Add to cart (data)
 *
 * @param data
 * @returns {Promise<*|undefined>}
 */

var addCartItemData = function addCartItemData(data) {
  try {
    return new Promise(function (resolve) {
      _service_event_bus__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dispatch(_service_event_bus__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].types.AddingToCart);
      Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* ajax */ "b"])("POST", "/cart/add.js", data).then(function (response) {
        resolve(response);
        _service_event_bus__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dispatch(_service_event_bus__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].types.AddedToCart, repsonse);
      });
    });
  } catch (e) {
    console.log("Error adding to cart.", e);
  }
};
/**
 *
 * Remove item from cart
 *
 * @param line
 * @returns {Promise<*|undefined>}
 */

var removeCartItem = function removeCartItem(line) {
  try {
    return new Promise(function (resolve) {
      Object(_utils_utils__WEBPACK_IMPORTED_MODULE_0__[/* ajax */ "b"])("POST", "/cart/change.js", JSON.stringify({
        quantity: 0,
        line: line
      })).then(function (response) {
        resolve(response);
        _service_event_bus__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].dispatch(_service_event_bus__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].types.RemovedFromCart, response);
      });
    });
  } catch (e) {
    console.log("Error removing item from cart.", e);
  }
};
/**
 *
 * Format number as money following Shopify's format.
 *
 * @param amount
 * @param decimalCount
 * @param decimal
 * @param thousands
 * @returns {string}
 */

var formatMoney = function formatMoney(amount) {
  var decimalCount = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;
  var decimal = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : ".";
  var thousands = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : ",";

  try {
    amount = amount / 100;
    decimalCount = Math.abs(decimalCount);
    decimalCount = isNaN(decimalCount) ? 2 : decimalCount;
    var negativeSign = amount < 0 ? "-" : "";
    var i = parseInt(amount = Math.abs(Number(amount) || 0).toFixed(decimalCount)).toString();
    var j = i.lenght > 3 ? i.length % 3 : 0; // decimalCount ? 
    //  (decimal + Math.abs(amount - i).toFied(decimalCount).slice(2) === '.00' ? null : )
    //(decimalCount ? decimal + Math.abs(amount - i).toFixed(decimalCount).slice(2) : ""));

    return "$" + negativeSign + (j ? i.substr(0, j) + thousands : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands) + (decimalCount ? decimal + Math.abs(amount - i).toFixed(decimalCount).slice(2) === '.00' ? '' : decimal + Math.abs(amount - i).toFixed(decimalCount).slice(2) : "");
  } catch (e) {
    console.log(e);
  }

  return amount;
};

/***/ }),

/***/ 36:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _lib_ajax_cart__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9);
/* harmony import */ var _services_service_cart__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e2) { throw _e2; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e3) { didErr = true; err = _e3; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

 // import { formatMoney } from "../utils/utils";



var QuickAdd = /*#__PURE__*/function () {
  function QuickAdd(element) {
    _classCallCheck(this, QuickAdd);

    this.element = element;
    this.collectionHandle = theme.collection;
    this.selectedVariantOptions = {
      option1: null,
      option2: null,
      option3: null
    };
    this.init();
  }

  _createClass(QuickAdd, [{
    key: "getElement",
    value: function getElement() {
      return this.element;
    }
  }, {
    key: "getButton",
    value: function getButton() {
      var element = this.getElement();
      return element.querySelectorAll('.js-quickAdd');
    }
  }, {
    key: "getPseudoAdd",
    value: function getPseudoAdd() {
      var element = this.getElement();
      return element.querySelectorAll('.js-pseudoAdd');
    }
  }, {
    key: "getAdd",
    value: function getAdd() {
      var element = this.getElement();
      return element.querySelectorAll('.js-quickSubmit');
    }
  }, {
    key: "getSelects",
    value: function getSelects() {
      var element = this.getElement();
      return element.querySelectorAll('.js-select');
    }
  }, {
    key: "getClose",
    value: function getClose() {
      var element = this.getElement();
      return element.querySelectorAll('.js-closeQuick');
    }
  }, {
    key: "getVariantSelect",
    value: function getVariantSelect() {
      var element = this.getElement();
      return element.querySelectorAll('.js-variants');
    }
  }, {
    key: "setClose",
    value: function setClose() {
      var closeEl = this.getClose();

      var _iterator = _createForOfIteratorHelper(closeEl),
          _step;

      try {
        var _loop = function _loop() {
          var close = _step.value;
          close.addEventListener('click', function (event) {
            event.preventDefault();
            var containerEl = close.closest('.js-container');
            var selectEl = containerEl.querySelectorAll('.js-select');
            var submitEl = containerEl.querySelector('.js-quickSubmit');
            var pseudoSubmit = containerEl.querySelector('.js-pseudoAdd');
            containerEl.querySelector('.js-wrapper').style.height = '100%';
            containerEl.classList.remove('active');
            containerEl.querySelector('.js-quickTitle').innerHTML = 'Add to cart';
            containerEl.querySelector('.js-quickPrice').innerHTML = '';
            containerEl.querySelector('.js-quickSubmit').dataset.id = '';
            containerEl.querySelector('.js-image').src = containerEl.querySelector('.js-image').dataset.initial;
            submitEl.setAttribute('disabled', true);
            submitEl.classList.add('hide-temp');
            pseudoSubmit.classList.remove('hide-temp');

            var _iterator2 = _createForOfIteratorHelper(selectEl),
                _step2;

            try {
              for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                var select = _step2.value;
                select.selectedIndex = 0;
              }
            } catch (err) {
              _iterator2.e(err);
            } finally {
              _iterator2.f();
            }
          });
        };

        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          _loop();
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
  }, {
    key: "findSelectedVariant",
    value: function findSelectedVariant() {
      var selectedVariantOptions = this.selectedVariantOptions;
      var productData = this.getProductJson();
      return productData.variants.find(function (variant) {
        return variant.option1 == selectedVariantOptions.option1 && variant.option2 == selectedVariantOptions.option2 && variant.option3 == selectedVariantOptions.option3;
      });
    }
  }, {
    key: "removeDefaultOptions",
    value: function removeDefaultOptions() {
      if (this.collectionHandle === 'sale') {
        var variantEl = this.getVariantSelect();

        var _iterator3 = _createForOfIteratorHelper(variantEl),
            _step3;

        try {
          for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
            var variant = _step3.value;
            var selectEl = variant.closest('.js-selector').querySelectorAll('.js-select');
            var options = variant.querySelectorAll('option');
            var option1 = Array.from(options).map(function (option) {
              return option.dataset.option1;
            }).filter(function (option) {
              return option !== undefined;
            });
            var option2 = Array.from(options).map(function (option) {
              return option.dataset.option2;
            }).filter(function (option) {
              return option !== undefined;
            });

            var newOption1 = _toConsumableArray(new Set(option1));

            var newOption2 = _toConsumableArray(new Set(option2));

            var _iterator4 = _createForOfIteratorHelper(selectEl),
                _step4;

            try {
              for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
                var select = _step4.value;

                if (select.dataset.position === '2') {
                  for (var i = select.length - 1; i >= 0; i--) {
                    var _select$options$i;

                    if ((newOption2 === null || newOption2 === void 0 ? void 0 : newOption2.includes(select === null || select === void 0 ? void 0 : (_select$options$i = select.options[i]) === null || _select$options$i === void 0 ? void 0 : _select$options$i.value)) === false) {
                      select.options.remove(i);
                    }
                  }
                }
              }
            } catch (err) {
              _iterator4.e(err);
            } finally {
              _iterator4.f();
            }
          }
        } catch (err) {
          _iterator3.e(err);
        } finally {
          _iterator3.f();
        }
      }
    }
  }, {
    key: "setDefault",
    value: function setDefault() {
      var selectEl = this.getSelects();
      var selectedVariant = this.selectedVariantOptions;
      var variantSelect;
      var selectedVariantEl;
      var option1;
      var option2;
      var imageEl;
      var containerEl;
      var urlEl;
      var varUrlEl;

      var _iterator5 = _createForOfIteratorHelper(selectEl),
          _step5;

      try {
        for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
          var _variantSelect, _variantSelect2;

          var select = _step5.value;
          //see if the href contains the variant= 
          urlEl = select.closest('.js-url').href;
          varUrlEl = urlEl.split('variant=')[1] || null;
          containerEl = select.closest('.js-container');
          variantSelect = containerEl.querySelector('.js-variants'); //if url did exist, select the first available variable, if not detect the selected variable

          varUrlEl !== null ? variantSelect.value = varUrlEl : null;
          selectedVariantEl = (_variantSelect = variantSelect) === null || _variantSelect === void 0 ? void 0 : _variantSelect.options[(_variantSelect2 = variantSelect) === null || _variantSelect2 === void 0 ? void 0 : _variantSelect2.selectedIndex]; //get both option values

          option1 = selectedVariantEl.dataset.option1;
          option2 = selectedVariantEl.dataset.option2; //as long as the default select is not default run code

          if (variantSelect.value !== 'Default') {
            if (select.name === 'Device') {
              containerEl = select.closest('.js-container');
              imageEl = containerEl.querySelector('.js-image');
              imageEl.dataset.src = selectedVariantEl.dataset.image;
              imageEl.dataset.initial = selectedVariantEl.dataset.image;
              imageEl.src = selectedVariantEl.dataset.image; // select.value = option2;

              select.dataset.position === '1' ? select.value = option1 : select.value = option2;
              select.dispatchEvent(new Event('change'));
            }

            if (select.name === 'Case Type') {
              select.value = option1;
              select.dispatchEvent(new Event('change'));
            }
          }
        }
      } catch (err) {
        _iterator5.e(err);
      } finally {
        _iterator5.f();
      }
    }
  }, {
    key: "setSelect",
    value: function setSelect() {
      var _this = this;

      var selectEl = this.getSelects();
      var selectedVariant = this.selectedVariantOptions;
      var availableCases;
      var availableProducts;
      var availableDevices;

      var _iterator6 = _createForOfIteratorHelper(selectEl),
          _step6;

      try {
        var _loop2 = function _loop2() {
          var select = _step6.value;
          select.addEventListener('click', function (event) {
            event.preventDefault();
          });
          select.addEventListener('change', function (event) {
            event.preventDefault();
            var position = select.dataset.position;
            var containerEl = select.closest('.js-container');
            var variantSelector = containerEl.querySelectorAll('.js-variants option');
            var addEl = containerEl.querySelector('.js-quickSubmit');
            var imageEl = containerEl.querySelector('.js-image');
            selectedVariant["option".concat(position)] = select.value; //if select is device, show certain cases

            if (select.name === 'Device') {
              //Get the cases that exist with the device selected
              availableCases = Array.from(variantSelector).filter(function (variant) {
                return variant.dataset.option1 === select.value || variant.dataset.option2 === select.value;
              }).map(function (test) {
                return test.dataset.option1;
              });
              availableProducts = Array.from(variantSelector).filter(function (variant) {
                return variant.dataset.option1 === select.value || variant.dataset.option2 === select.value;
              }).map(function (test) {
                return test.dataset.available;
              }); //If there are cases

              if (availableCases.length > 0) {
                try {
                  (function () {
                    var pseudoSelector = select.closest('.js-selector').querySelectorAll('.js-pseudo div');
                    var pseudoSelectorVal = Array.from(pseudoSelector).map(function (pseudo) {
                      return pseudo.dataset.value;
                    });
                    var caseSelector = select.closest('.js-selector').querySelector('select[name="Case Type"]');
                    var caseSelects = select.closest('.js-selector').querySelectorAll('select[name="Case Type"] option'); // availableCases check against pseudoCases and return ones that match
                    // then match against the actual case selector, see if it already exists, if not add 

                    var existingCases = availableCases.filter(function (element) {
                      return pseudoSelectorVal.includes(element);
                    });

                    var _iterator7 = _createForOfIteratorHelper(caseSelects),
                        _step7;

                    try {
                      for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
                        var caseSelect = _step7.value;
                        caseSelect.value !== 'Case Type' ? caseSelect.remove() : null;
                      }
                    } catch (err) {
                      _iterator7.e(err);
                    } finally {
                      _iterator7.f();
                    }

                    var _iterator8 = _createForOfIteratorHelper(existingCases.entries()),
                        _step8;

                    try {
                      var _loop3 = function _loop3() {
                        var _step8$value = _slicedToArray(_step8.value, 2),
                            index = _step8$value[0],
                            existingCase = _step8$value[1];

                        caseSelector.add(new Option("".concat(existingCase, " ").concat(availableProducts[index] === 'false' ? '- Sold Out' : ''), existingCase));
                        availableProducts[index] === 'false' ? caseSelector.querySelector("option[value=\"".concat(existingCase, "\"")).setAttribute('disabled', true) : caseSelector.querySelector("option[value=\"".concat(existingCase, "\"")).removeAttribute('disabled');

                        if (_this.selectedVariantOptions['option1'] === existingCase && availableProducts[index] === 'true') {
                          console.log('triggered');
                          setTimeout(function () {
                            caseSelector.value = existingCase;
                          }, 100);
                        }
                      };

                      for (_iterator8.s(); !(_step8 = _iterator8.n()).done;) {
                        _loop3();
                      }
                    } catch (err) {
                      _iterator8.e(err);
                    } finally {
                      _iterator8.f();
                    }
                  })();
                } catch (_unused) {}
              }
            }

            var selectedProduct = Array.from(variantSelector).find(function (variant) {
              if (variant.dataset.option2 !== undefined) {
                if (selectedVariant.option1 === variant.dataset.option1 && selectedVariant.option2 == variant.dataset.option2) {
                  return variant;
                }
              } else {
                if (selectedVariant.option1 === variant.dataset.option1) {
                  return variant;
                }
              }
            });

            if (selectedProduct) {
              if (selectedProduct.dataset.quantity > 0) {
                try {
                  addEl.removeAttribute('disabled');
                  addEl.querySelector('.js-quickTitle').innerHTML = 'Add To Cart';
                  addEl.querySelector('.js-quickPrice').innerHTML = "\u2014  ".concat(Object(_services_service_cart__WEBPACK_IMPORTED_MODULE_1__[/* formatMoney */ "a"])(selectedProduct.dataset.price));
                } catch (_unused2) {}
              } else {
                addEl.querySelector('.js-quickTitle').innerHTML = "Sold Out";
                addEl.querySelector('.js-quickPrice').innerHTML = '';
                addEl.setAttribute('disabled', true);
              }

              try {
                addEl.dataset.compare = selectedProduct.dataset.compare;
                addEl.dataset.id = selectedProduct.value;
                imageEl.src = selectedProduct.dataset.image;
                imageEl.dataset.src = selectedProduct.dataset.image;
              } catch (_unused3) {}
            } else {
              var _addEl$closest;

              if (addEl !== null && addEl !== void 0 && (_addEl$closest = addEl.closest('.js-container')) !== null && _addEl$closest !== void 0 && _addEl$closest.classList.contains('active')) {
                addEl.setAttribute('disabled', true);
              }

              try {
                addEl.querySelector('.js-quickTitle').innerHTML = 'Add to cart';
              } catch (_unused4) {}

              if (select.name === 'Device') {
                try {
                  var caseSelector = select.closest('.js-selector').querySelector('select[name="Case Type"]');
                  caseSelector.value = 'Case Type';
                } catch (_unused5) {}
              } else if (select.name === 'Case Type') {
                try {
                  var deviceSelector = select.closest('.js-selector').querySelector('select[name="Device"]');
                  deviceSelector.value = 'Model';
                } catch (_unused6) {}
              }
            }
          });
        };

        for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
          _loop2();
        }
      } catch (err) {
        _iterator6.e(err);
      } finally {
        _iterator6.f();
      }
    }
  }, {
    key: "setPseudoAdd",
    value: function setPseudoAdd() {
      var addEl = this.getPseudoAdd();

      var _iterator9 = _createForOfIteratorHelper(addEl),
          _step9;

      try {
        var _loop4 = function _loop4() {
          var add = _step9.value;
          add.addEventListener('click', function (event) {
            event.preventDefault();
            var containerEl = add.closest('.js-container');
            var selectorEl = containerEl.querySelector('.js-selector');
            var wrapperEl = containerEl.querySelector('.js-wrapper');

            if (!containerEl.classList.contains('active')) {
              var submitEl = add.closest('.js-selector').querySelector('.js-quickSubmit');
              selectorEl.style.height = selectorEl.scrollHeight + 'px';
              wrapperEl.style.setProperty('height', "calc(100% - ".concat(selectorEl.scrollHeight, "px"));
              containerEl.classList.add('active');
              submitEl.disabled = true;
              submitEl.classList.remove('hide-temp');
              submitEl.querySelector('.js-quickTitle').innerHTML !== 'Sold Out' ? submitEl.removeAttribute('disabled') : '';
              add.classList.add('hide-temp');
            }
          });
        };

        for (_iterator9.s(); !(_step9 = _iterator9.n()).done;) {
          _loop4();
        }
      } catch (err) {
        _iterator9.e(err);
      } finally {
        _iterator9.f();
      }
    }
  }, {
    key: "setAdd",
    value: function setAdd() {
      var addEl = this.getAdd();
      var finalSaleTag;
      var promoCode;
      var offerText;
      var content;
      var addedText;
      var infoText;
      var comparePrice;

      var _iterator10 = _createForOfIteratorHelper(addEl),
          _step10;

      try {
        var _loop5 = function _loop5() {
          var add = _step10.value;
          add.addEventListener('click', function (event) {
            event.preventDefault();
            comparePrice = add.dataset.compare || '';
            finalSaleTag = add.dataset["final"];
            promoCode = add.dataset.promo;
            offerText = add.dataset.offer;
            content;
            finalSaleTag === 'true' ? content = {
              'finalSale': true
            } : null;
            promoCode !== '' ? content = _objectSpread(_objectSpread({}, content), {
              "promoCode": promoCode
            }) : null;
            offerText !== '' ? content = _objectSpread(_objectSpread({}, content), {
              "offerText": offerText
            }) : null;
            comparePrice !== '' ? content = _objectSpread(_objectSpread({}, content), {
              'compare_price': comparePrice
            }) : null;
            comparePrice !== '' ? content = _objectSpread(_objectSpread({}, content), {
              'LPROP': 'Final Sale'
            }) : null;

            if (add.dataset.id == '') {} else {
              addedText = add.querySelector('.js-addingInfo');
              infoText = add.querySelector('.js-addedText');
              Object(_lib_ajax_cart__WEBPACK_IMPORTED_MODULE_0__[/* addToCart */ "b"])(add.dataset.id, 1, content);
              add.setAttribute('disabled', true);
              addedText.classList.add('hide');
              infoText.classList.remove('hide');
              setTimeout(function () {
                addedText.classList.remove('hide');
                infoText.classList.add('hide');
                add.removeAttribute('disabled');
              }, 2000);
            }
          });
        };

        for (_iterator10.s(); !(_step10 = _iterator10.n()).done;) {
          _loop5();
        }
      } catch (err) {
        _iterator10.e(err);
      } finally {
        _iterator10.f();
      }
    }
  }, {
    key: "setButton",
    value: function setButton() {
      var buttonEl = this.getButton();

      var _iterator11 = _createForOfIteratorHelper(buttonEl),
          _step11;

      try {
        var _loop6 = function _loop6() {
          var button = _step11.value;
          button.addEventListener('click', function (event) {
            event.preventDefault();
            var containerEl = button.closest('.js-container');
            var selectorEl = containerEl.querySelector('.js-selector');
            var wrapperEl = containerEl.querySelector('.js-wrapper');
            var addEl = containerEl.querySelector('.js-quickSubmit');
            var imageEl = containerEl.querySelector('.js-image');
            var selectEl = containerEl.querySelectorAll('.js-select');

            if (containerEl.classList.contains('active')) {
              selectorEl.style.height = '0px';
              wrapperEl.style.height = "100%";
              addEl.querySelector('.js-quickPrice').innerHTML = '';
              imageEl.src = imageEl.dataset.initial;
              imageEl.dataset.src = imageEl.dataset.initial;

              var _iterator12 = _createForOfIteratorHelper(selectEl),
                  _step12;

              try {
                for (_iterator12.s(); !(_step12 = _iterator12.n()).done;) {
                  var select = _step12.value;
                  select.selectedIndex = 0;
                }
              } catch (err) {
                _iterator12.e(err);
              } finally {
                _iterator12.f();
              }
            } else {
              selectorEl.style.height = selectorEl.scrollHeight + 'px';
              wrapperEl.style.setProperty('height', "calc(100% - 40px - ".concat(selectorEl.scrollHeight, "px"));
            }

            containerEl.classList.toggle('active');
          });
        };

        for (_iterator11.s(); !(_step11 = _iterator11.n()).done;) {
          _loop6();
        }
      } catch (err) {
        _iterator11.e(err);
      } finally {
        _iterator11.f();
      }
    }
  }, {
    key: "setEventHandlers",
    value: function setEventHandlers() {
      this.setPseudoAdd();
      this.setAdd();
      this.setSelect();
      this.setButton();
      this.setClose();
      this.removeDefaultOptions();
      this.setDefault();
    }
  }, {
    key: "init",
    value: function init() {
      this.setEventHandlers();
    }
  }]);

  return QuickAdd;
}();

var QuickAddInit = {
  init: function init(container) {
    var $el = document.querySelectorAll(".js-productCard");

    if (container || $el) {
      if (container !== undefined) {
        new QuickAdd(container);
      } else {
        var _iterator13 = _createForOfIteratorHelper($el),
            _step13;

        try {
          for (_iterator13.s(); !(_step13 = _iterator13.n()).done;) {
            var $e = _step13.value;
            new QuickAdd($e);
          }
        } catch (err) {
          _iterator13.e(err);
        } finally {
          _iterator13.f();
        }
      }
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (QuickAddInit);

/***/ }),

/***/ 419:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _component_quickAdd__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(36);
function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }



var Sort = /*#__PURE__*/function () {
  function Sort(element) {
    _classCallCheck(this, Sort);

    this.element = element;
    this.init();
  }

  _createClass(Sort, [{
    key: "getElement",
    value: function getElement() {
      return this.element;
    }
  }, {
    key: "getHtml",
    value: function getHtml() {
      var element = this.getElement();
      return element.closest('html');
    }
  }, {
    key: "getHeader",
    value: function getHeader() {
      var element = this.getElement();
      return element.closest('body').querySelector('.section-header');
    }
  }, {
    key: "getForm",
    value: function getForm() {
      var element = this.getElement();
      return element.querySelector('.js-sortForm');
    }
  }, {
    key: "getButton",
    value: function getButton() {
      var element = this.getElement();
      return element.querySelector('.js-sortButton');
    }
  }, {
    key: "getClose",
    value: function getClose() {
      var element = this.getElement();
      return element.querySelectorAll('.js-sortClose');
    }
  }, {
    key: "getDropdown",
    value: function getDropdown() {
      var element = this.getElement();
      return element.querySelector('.js-sortDropdown');
    }
  }, {
    key: "getContainer",
    value: function getContainer() {
      var element = this.getElement();
      return element.closest('.js-pcp').querySelector('.js-collectionContainer');
    }
  }, {
    key: "getUrl",
    value: function getUrl() {
      return window.location.href;
    }
  }, {
    key: "getInput",
    value: function getInput() {
      var element = this.getElement();
      return element.querySelectorAll('.js-sortInput');
    }
  }, {
    key: "getHandle",
    value: function getHandle() {
      var element = this.getElement();
      return element.dataset.handle;
    }
  }, {
    key: "getOverlay",
    value: function getOverlay() {
      var element = this.getElement();
      return element.querySelector('.js-sortOverlay');
    }
  }, {
    key: "getPagination",
    value: function getPagination() {
      var element = this.getElement();
      return element.closest('.js-pcp').querySelector('.js-pagination');
    }
  }, {
    key: "getLoad",
    value: function getLoad() {
      var element = this.getElement();
      return element.closest('.js-pcp').querySelector('.js-load');
    }
  }, {
    key: "getCount",
    value: function getCount() {
      var element = this.getElement();
      return element.closest('.js-pcp').querySelector('.js-collectionViewed');
    }
  }, {
    key: "getTotalCount",
    value: function getTotalCount() {
      var element = this.getElement();
      return element.closest('.js-pcp').querySelector('.js-totalView');
    }
  }, {
    key: "getCurrentCount",
    value: function getCurrentCount() {
      var element = this.getElement();
      return element.closest('.js-pcp').querySelector('.js-currentCount');
    }
  }, {
    key: "setInput",
    value: function setInput() {
      var _this = this;

      var inputEl = this.getInput();

      var _iterator = _createForOfIteratorHelper(inputEl),
          _step;

      try {
        var _loop = function _loop() {
          var input = _step.value;
          input.addEventListener('click', function () {
            var formData = new FormData(input.closest('.js-filterForm'));
            var query = new URLSearchParams(formData).toString();

            _this.getFetch("".concat(window.location.pathname, "?").concat(query));
          });
        };

        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          _loop();
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
  }, {
    key: "setClose",
    value: function setClose() {
      var _this2 = this;

      var closeEl = this.getClose();
      var dropdownEl = this.getDropdown();

      var _iterator2 = _createForOfIteratorHelper(closeEl),
          _step2;

      try {
        for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
          var close = _step2.value;
          close.addEventListener('click', function () {
            dropdownEl.classList.remove('active');

            _this2.hideOverlay();
          });
        }
      } catch (err) {
        _iterator2.e(err);
      } finally {
        _iterator2.f();
      }
    }
  }, {
    key: "showOverlay",
    value: function showOverlay() {
      var overlayEl = this.getOverlay();
      var headerEl = this.getHeader();
      var htmlEl = this.getHtml();
      var windowWidth = window.matchMedia("(min-width:1025px");

      if (!windowWidth.matches) {
        htmlEl.classList.add('active-filter');
        headerEl.classList.add('deactive');
        overlayEl.classList.add('active');
      }

      windowWidth.addListener(function (e) {
        if (!e.matches) {
          htmlEl.classList.add('active-filter');
          headerEl.classList.add('deactive');
          overlayEl.classList.add('active');
        }
      });
    }
  }, {
    key: "hideOverlay",
    value: function hideOverlay() {
      var windowWidth = window.matchMedia("(min-width:1025px)");
      var overlayEl = this.getOverlay();
      var headerEl = this.getHeader();
      var htmlEl = this.getHtml();

      if (!windowWidth.matches) {
        htmlEl.classList.remove('active-filter');
        headerEl.classList.remove('deactive');
        overlayEl.classList.remove('active');
      }

      windowWidth.addListener(function (e) {
        if (!e.matches) {
          htmlEl.classList.remove('active-filter');
          headerEl.classList.remove('deactive');
          overlayEl.classList.remove('active');
        }
      });
    }
  }, {
    key: "openFilter",
    value: function openFilter() {
      var _this3 = this;

      var filterButtonEl = this.getButton();
      var dropdownEl = this.getDropdown();
      var overlayEl = this.getOverlay();
      var headerEl = this.getHeader();
      var htmlEl = this.getHtml();
      filterButtonEl.addEventListener('click', function () {
        dropdownEl.classList.toggle('active');
        filterButtonEl.closest('.js-sortContainer').classList.toggle('active');

        _this3.showOverlay();
      });
    }
  }, {
    key: "getFetch",
    value: function getFetch(sortUrl) {
      var containerEl = this.getContainer();
      var pagination = this.getPagination();
      var viewedEl = this.getCount();
      var loadEl = this.getLoad();
      var currentCount = this.getCurrentCount();
      var totalCount = this.getTotalCount();
      fetch(sortUrl, {
        header: {
          "Content-Type": "application/json",
          Accept: "application/json"
        }
      }).then(function (data) {
        return data.text();
      }).then(function (html) {
        var parser = new DOMParser();
        var doc = parser.parseFromString(html, "text/html");
        var collectionEl = doc.querySelector(".js-collectionContainer");
        var paginationEl = doc.querySelector('.js-pagination');
        var totalCountEl = doc.querySelector('.js-totalView');
        containerEl.innerHTML = "";
        containerEl.innerHTML = collectionEl.innerHTML;

        if (paginationEl === null) {
          loadEl.style.display = 'none';
        } else {
          pagination.innerHTML = '';
          pagination.innerHTML = paginationEl.innerHTML;
          loadEl.style.display = 'block';
        }

        totalCount.innerHTML = totalCountEl.innerHTML;
        currentCount.innerHTML = "".concat(totalCountEl.innerHTML, " Results");
        viewedEl.innerHTML = collectionEl.childElementCount;
        new _component_quickAdd__WEBPACK_IMPORTED_MODULE_0__["default"].init();
      });
    }
  }, {
    key: "setEventHandlers",
    value: function setEventHandlers() {
      this.openFilter();
      this.setInput();
      this.setClose();
    }
  }, {
    key: "init",
    value: function init() {
      this.setEventHandlers();
    }
  }]);

  return Sort;
}();

var SortInit = {
  init: function init() {
    var $el = document.querySelector(".js-filter");

    if ($el) {
      new Sort($el);
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (SortInit);

/***/ }),

/***/ 5:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/** 
 * EventBus
 * Defines expected events
 * disppatches events by type
 * handles event listeners by type
 **/
var eventBus = {
  types: {
    AddingToCart: 'mx_shopify.cart.adding',
    AddedToCart: 'mx_shopify.cart.added',
    GettingCart: 'mx_shopify.cart.getting',
    CartUpdated: 'mx_shopify.cart.updated',
    RemovedFromCart: 'mx_shopify.cart.removed',
    QuantityUpdated: 'mx_shopify.quantity.updated',
    OptionsSelected: 'mx_shopify.options.selected',
    AjaxCartRefreshed: 'mx_shopify.cart.ajax.refreshed'
  },
  dispatch: function dispatch($event, $data) {
    $data = typeof $data !== 'undefined' ? $data : {};
    document.dispatchEvent(new CustomEvent($event, {
      detail: $data
    }));
  },
  on: function on($event, func) {
    document.addEventListener($event, func);
  },
  off: function off($event, func) {
    document.removeEventListener($event, func);
  }
};
/* harmony default export */ __webpack_exports__["a"] = (eventBus);

/***/ }),

/***/ 9:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return addToCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return addMultipleToCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return getCart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return getCartToken; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return changeCart; });
/* unused harmony export updateCart */
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

var addToCart = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(id, quantity, properties) {
    var data,
        formData,
        res,
        _args = arguments;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            data = _args.length > 3 && _args[3] !== undefined ? _args[3] : {};
            formData = {
              id: id,
              quantity: quantity,
              properties: properties
            };
            _context.next = 4;
            return fetch("/cart/add.js", {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify(formData)
            }).then(function (response) {
              return response.json();
            }).then(function (json) {
              getCart();
              var cartEl = document.querySelector(".MiniCart");
              cartEl.classList.add("active");
            })["catch"](function (err) {
              /* uh oh, we have error. */
              console.error(err);
            });

          case 4:
            res = _context.sent;
            return _context.abrupt("return", res);

          case 6:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function addToCart(_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
}();
var addMultipleToCart = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(items) {
    var data,
        res,
        _args2 = arguments;
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            data = _args2.length > 1 && _args2[1] !== undefined ? _args2[1] : {};
            _context2.next = 3;
            return fetch("/cart/add.js", {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                items: items
              })
            }).then(function (response) {
              return response.json();
            }).then(function (json) {
              getCart();
              var cartEl = document.querySelector(".MiniCart");
              cartEl.classList.add("active");
            })["catch"](function (err) {
              /* uh oh, we have error. */
              console.error(err);
            });

          case 3:
            res = _context2.sent;
            return _context2.abrupt("return", res);

          case 5:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));

  return function addMultipleToCart(_x4) {
    return _ref2.apply(this, arguments);
  };
}(); // export const getCart = async () => {
//   const res = await fetch("/cart?view=compare", {
//     method: 'GET'
//   })
//   .then(function (response) {
//     return response.text();
//   })  
//   .then(html => {
//     // Here, you have the HTML result
//     var temp = document.createElement('div');
//     temp.innerHTML = html;
//     let test = temp.querySelector('.shopify-section').innerHTML;
//     return JSON.parse(test);
//   })
//   .catch(function (err){
//     console.log(err, 'getcart')
//   });
//   var event = new CustomEvent("cartUpdated", { detail: res });
//   document.dispatchEvent(event);
//   return res;
// }

var getCart = /*#__PURE__*/function () {
  var _ref3 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
    var res, event;
    return regeneratorRuntime.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return fetch("/cart.js", {
              method: 'GET',
              headers: {
                'Content-Type': 'application/json'
              }
            }).then(function (response) {
              return response.json();
            })["catch"](function (err) {
              console.log(err, 'getcart');
            });

          case 2:
            res = _context3.sent;
            event = new CustomEvent("cartUpdated", {
              detail: res
            });
            document.dispatchEvent(event);
            return _context3.abrupt("return", res);

          case 6:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));

  return function getCart() {
    return _ref3.apply(this, arguments);
  };
}();
var getCartToken = /*#__PURE__*/function () {
  var _ref4 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
    var res;
    return regeneratorRuntime.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return fetch("/cart.js", {
              method: 'GET',
              headers: {
                'Content-Type': 'application/json'
              }
            }).then(function (response) {
              return response.json();
            })["catch"](function (err) {
              console.log(err, 'getcart');
            });

          case 2:
            res = _context4.sent;
            return _context4.abrupt("return", res.token);

          case 4:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));

  return function getCartToken() {
    return _ref4.apply(this, arguments);
  };
}();
var changeCart = function changeCart(id, quantity) {
  var formData = {
    "id": "".concat(id),
    quantity: quantity
  };
  return fetch("/cart/change.js", {
    method: 'POST',
    credentials: 'same-origin',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(formData)
  }).then(function (res) {
    return res;
  });
};
var updateCart = /*#__PURE__*/function () {
  var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee5(id, quantity) {
    var data,
        serializeExist,
        content,
        formData,
        res,
        _args5 = arguments;
    return regeneratorRuntime.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            data = _args5.length > 2 && _args5[2] !== undefined ? _args5[2] : {};
            serializeExist = _args5.length > 3 ? _args5[3] : undefined;
            content = _args5.length > 4 ? _args5[4] : undefined;
            formData = {
              id: id,
              quantity: quantity
            };
            res = fetch("/cart/update.js", {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify(formData)
            }).then(function (response) {
              return response.json();
            }).then(function (json) {})["catch"](function (err) {
              /* uh oh, we have error. */
              console.error(err, 'update');
            });
            return _context5.abrupt("return", res);

          case 6:
          case "end":
            return _context5.stop();
        }
      }
    }, _callee5);
  }));

  return function updateCart(_x5, _x6) {
    return _ref5.apply(this, arguments);
  };
}();

/***/ })

/******/ });
//# sourceMappingURL=component.sort.js.map