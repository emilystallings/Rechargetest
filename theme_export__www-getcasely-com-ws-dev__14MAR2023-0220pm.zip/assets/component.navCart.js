/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 481);
/******/ })
/************************************************************************/
/******/ ({

/***/ 1:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export pipe */
/* unused harmony export compose */
/* unused harmony export map */
/* unused harmony export filter */
/* unused harmony export pluck */
/* unused harmony export sort */
/* unused harmony export mapDOMElements */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return selectAll; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return selectArr; });
/* unused harmony export select */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return selectDoc; });
/* unused harmony export value */
/* unused harmony export getElems */
/* unused harmony export dataValue */
/* unused harmony export removeAttribute */
/* unused harmony export closest */
/* unused harmony export remove */
/* unused harmony export nextSibling */
/* unused harmony export prevSibling */
/* unused harmony export toggleAttr */
/* unused harmony export setAttr */
/* unused harmony export getAttr */
/* unused harmony export submit */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "l", function() { return toggleClass; });
/* unused harmony export setText */
/* unused harmony export setHtml */
/* unused harmony export opacity */
/* unused harmony export styles */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return hasClass; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return isVisible; });
/* unused harmony export removeClassAll */
/* unused harmony export addClassAll */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return addClass; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return removeClass; });
/* unused harmony export toggleClassAll */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return event; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return ajax; });
/* unused harmony export observeAdd */
/* unused harmony export observeRemove */
/* unused harmony export cartesian */
/* unused harmony export count */
/* unused harmony export goTo */
/* unused harmony export insertSortedValue */
/* unused harmony export serialize */
/* unused harmony export getQueryValue */
/* unused harmony export asyncForEach */
/* unused harmony export MONEY_FORMATS */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return formatMoney; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return imageSize; });
function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e2) { throw _e2; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e3) { didErr = true; err = _e3; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/*
  The purpose of this file is generate/introduce a toolbelt (Similar to loadash, Ramda, RxJS)
  following the DRY principle and functional programming practices
*/

/*
 Composition functions
*/

/*
  Pipe is a function to create composition of functions (using map, filter, sort, etc)
  Usage example: https://www.freecodecamp.org/news/pipe-and-compose-in-javascript-5b04004ac937/
  External resources: https://medium.com/javascript-scene/tagged/functional-programming
*/
var pipe = function pipe() {
  for (var _len = arguments.length, fns = new Array(_len), _key = 0; _key < _len; _key++) {
    fns[_key] = arguments[_key];
  }

  return function (x) {
    return fns.reduce(function (v, f) {
      return f(v);
    }, x);
  };
};
var compose = function compose() {
  for (var _len2 = arguments.length, fns = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    fns[_key2] = arguments[_key2];
  }

  return function (x) {
    return fns.reduceRight(function (v, f) {
      return f(v);
    }, x);
  };
};
var map = function map(f) {
  return function (arr) {
    return arr.reduce(function (acc, x) {
      return [].concat(_toConsumableArray(acc), [f(x)]);
    }, []);
  };
};
var filter = function filter(f) {
  return function (arr) {
    return arr.reduce(function (acc, x) {
      return f(x) ? [].concat(_toConsumableArray(acc), [x]) : acc;
    }, []);
  };
};
var pluck = function pluck(str) {
  return function (arr) {
    return arr.reduce(function (acc, x) {
      return [].concat(_toConsumableArray(acc), [_defineProperty({}, str, x[str])]);
    }, []);
  };
};
var sort = function sort(fn) {
  return function (arr) {
    return arr.reduce(insertSortedValue(fn), []);
  };
};
/*
  General DOM functions
  Use these functions to select, handle html elements (similar to jQuery)
*/
//Apply/Loop function to a group of html elements

var mapDOMElements = function mapDOMElements(fn) {
  return function (items) {
    return _toConsumableArray(items).forEach(fn);
  };
};
var selectAll = function selectAll(query) {
  var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return item.querySelectorAll(query);
};
var selectArr = function selectArr(query) {
  var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return [].slice.call(item.querySelectorAll(query));
};
var select = function select() {
  var item = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : document;
  var query = arguments.length > 1 ? arguments[1] : undefined;
  return item.querySelector(query);
};
var selectDoc = function selectDoc(query) {
  var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return item.querySelector(query);
};
var value = function value(query) {
  var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return item.querySelector(query).value;
}; //General query for elements equivalent to $()

var getElems = function getElems(query) {
  var item = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return _toConsumableArray(item.querySelectorAll(query));
};
var dataValue = function dataValue(_ref2) {
  var dataset = _ref2.dataset;
  return function (id) {
    return dataset[id];
  };
};
/*
  General DOM functions
  Use these functions to update html elements (similar to jQuery)
*/

var removeAttribute = function removeAttribute(tag) {
  return function (item) {
    return item.removeAttribute(tag);
  };
};
var closest = function closest(item) {
  return function (query) {
    return item.closest(query);
  };
};
var remove = function remove(item) {
  return item.parentNode.removeChild(item);
};
var nextSibling = function nextSibling(item) {
  return item.nextElementSibling;
};
var prevSibling = function prevSibling(item) {
  return item.previousElementSibling;
};
var toggleAttr = function toggleAttr(item, attr) {
  return item.toggleAttribute(attr);
};
var setAttr = function setAttr(attr, value) {
  return function (item) {
    return item.setAttribute(attr, value);
  };
};
var getAttr = function getAttr(attr) {
  return function (item) {
    return item.getAttribute(attr);
  };
};
var submit = function submit(item) {
  return item.submit(item);
};
var toggleClass = function toggleClass(item, cls) {
  return item.classList.toggle(cls);
};
var setText = function setText(item) {
  return function (text) {
    return item.innerText = text;
  };
};
var setHtml = function setHtml(item) {
  return function (html) {
    return item.innerHTML = html;
  };
};
var opacity = function opacity(value) {
  return function (item) {
    return item.style.opacity = "".concat(value);
  };
};
var styles = function styles(elem, _styles) {
  return elem.setAttribute("style", Object.entries(_styles).map(function (_ref3) {
    var _ref4 = _slicedToArray(_ref3, 2),
        key = _ref4[0],
        value = _ref4[1];

    return "".concat(key, ": ").concat(value, ";");
  }).join(' '));
};
/*
jpgg
*/

var hasClass = function hasClass(target, className) {
  return new RegExp('(\\s|^)' + className + '(\\s|$)').test(target.className);
};
var isVisible = function isVisible(elem) {
  return !!elem && !!(elem.offsetWidth || elem.offsetHeight || elem.getClientRects().length);
}; // source (2018-03-11): https://github.com/jquery/jquery/blob/master/src/css/hiddenVisibleSelectors.js

var removeClassAll = function removeClassAll(list, cls) {
  return list.map(function (l) {
    return l.classList.remove(cls);
  });
};
var addClassAll = function addClassAll(list, cls) {
  return list.map(function (l) {
    return l.classList.add(cls);
  });
};
var addClass = function addClass(e, cls) {
  return !hasClass(e, cls) ? e.classList.add(cls) : false;
};
var removeClass = function removeClass(e, cls) {
  return hasClass(e, cls) ? e.classList.remove(cls) : false;
};
var toggleClassAll = function toggleClassAll(items, cls) {
  return [].slice.call(items).map(function (item) {
    return item.classList.toggle(cls);
  });
};
var event = function event(elem, _event, func) {
  return elem ? elem.addEventListener(_event, func) : console.log('Invalid element to apply ' + _event + ': ' + func);
};
var ajax = /*#__PURE__*/function () {
  var _ref5 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(method, url) {
    var data,
        contentType,
        xhttp,
        _args = arguments;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            data = _args.length > 2 && _args[2] !== undefined ? _args[2] : {};
            contentType = _args.length > 3 && _args[3] !== undefined ? _args[3] : 'application/json';
            xhttp = _args.length > 4 && _args[4] !== undefined ? _args[4] : null;
            return _context.abrupt("return", new Promise(function (resolve) {
              if (!xhttp) {
                xhttp = new XMLHttpRequest();
              }

              xhttp.onreadystatechange = function () {
                if (xhttp.readyState === 4) {
                  resolve(JSON.stringify({
                    status: xhttp.status,
                    response: xhttp.responseText
                  }));
                }
              };

              xhttp.open(method, url, true);

              if (method === 'POST' && data) {
                xhttp.setRequestHeader('Content-type', contentType);
                xhttp.send(data);
              } else {
                xhttp.send();
              }

              return xhttp;
            }));

          case 4:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function ajax(_x, _x2) {
    return _ref5.apply(this, arguments);
  };
}();
var observeAdd = /*#__PURE__*/function () {
  var _ref6 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(container, callback) {
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            new MutationObserver(function (mutationsList, observer) {
              var _iterator = _createForOfIteratorHelper(mutationsList),
                  _step;

              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var mutation = _step.value;

                  if (mutation.type === 'childList') {
                    var nodes = [].slice.call(mutation.addedNodes);

                    if (nodes.length > 0) {
                      callback(nodes);
                    }
                  }
                }
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
            }).observe(container, {
              attributes: true,
              childList: true,
              subtree: true
            });

          case 1:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));

  return function observeAdd(_x3, _x4) {
    return _ref6.apply(this, arguments);
  };
}();
var observeRemove = /*#__PURE__*/function () {
  var _ref7 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3(container, callback) {
    return regeneratorRuntime.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            new MutationObserver(function (mutationsList, observer) {
              var _iterator2 = _createForOfIteratorHelper(mutationsList),
                  _step2;

              try {
                for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                  var mutation = _step2.value;

                  if (mutation.type === 'childList') {
                    var nodes = [].slice.call(mutation.removedNodes);

                    if (nodes.length > 0) {
                      callback(nodes);
                    }
                  }
                }
              } catch (err) {
                _iterator2.e(err);
              } finally {
                _iterator2.f();
              }
            }).observe(container, {
              attributes: true,
              childList: true,
              subtree: true
            });

          case 1:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));

  return function observeRemove(_x5, _x6) {
    return _ref7.apply(this, arguments);
  };
}();
var cartesian = function cartesian() {
  for (var _len3 = arguments.length, a = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
    a[_key3] = arguments[_key3];
  }

  return a.reduce(function (a, b) {
    return a.flatMap(function (d) {
      return b.map(function (e) {
        return [d, e].flat();
      });
    });
  });
};
/*
  General purpose functions
  Use these functions to apply certain operation in your context
*/

var count = function count(str) {
  return str.length;
};
var goTo = function goTo(URL) {
  return window.location.href = URL;
};
var insertSortedValue = function insertSortedValue(fn) {
  return function (arr, value) {
    return [].concat(_toConsumableArray(arr.filter(function (n) {
      return !fn(n, value);
    })), [value], _toConsumableArray(arr.filter(function (n) {
      return fn(n, value);
    })));
  };
};
var serialize = function serialize(form) {
  return Array.from(new FormData(form), function (e) {
    return e.map(encodeURIComponent).join('=');
  }).join('&');
};
var getQueryValue = function getQueryValue(value) {
  return new URLSearchParams(window.location.search).get(value);
};
var asyncForEach = /*#__PURE__*/function () {
  var _ref8 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee4(array, callback) {
    var index;
    return regeneratorRuntime.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            console.log(array, 'ok');
            index = 0;

          case 2:
            if (!(index < array.length)) {
              _context4.next = 8;
              break;
            }

            _context4.next = 5;
            return callback(array[index], index, array);

          case 5:
            index++;
            _context4.next = 2;
            break;

          case 8:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));

  return function asyncForEach(_x7, _x8) {
    return _ref8.apply(this, arguments);
  };
}();
var MONEY_FORMATS = {
  AMOUT: "${{amount}}",
  AMOUT_NO_DECIMALS: "${{amount_no_decimals}}"
}; // eslint-disable-next-line class-methods-use-this

var formatMoney = function formatMoney(cents) {
  var format = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : MONEY_FORMATS.AMOUT_NO_DECIMALS;
  if (typeof cents === "string") cents = cents.replace(".", "");
  var value = "";
  var placeholderRegex = /\{\{\s*(\w+)\s*\}\}/;
  var formatString = format;

  function formatWithDelimiters(number) {
    var precision = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;
    var thousands = arguments.length > 2 ? arguments[2] : undefined;
    var decimal = arguments.length > 3 ? arguments[3] : undefined;
    thousands = thousands || ",";
    decimal = decimal || ".";

    if (Number.isNaN(number) || number == null) {
      return 0;
    }

    number = (number / 100.0).toFixed(precision);
    var parts = number.split(".");
    var dollarsAmount = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "£1" + thousands);
    var centsAmount = parts[1] ? decimal + parts[1] : "";
    return dollarsAmount + centsAmount;
  }

  switch (formatString.match(placeholderRegex)[1]) {
    case "amount":
      value = formatWithDelimiters(cents, 2);
      break;

    case "amount_no_decimals":
      value = formatWithDelimiters(cents, 0);
      break;

    case "amount_with_comma_separator":
      value = formatWithDelimiters(cents, 2, ".", ",");
      break;

    case "amount_no_decimals_with_comma_separator":
      value = formatWithDelimiters(cents, 0, ".", ",");
      break;

    case "amount_no_decimals_with_space_separator":
      value = formatWithDelimiters(cents, 0, " ");
      break;

    default:
      value = formatWithDelimiters(cents, 2);
      break;
  }

  return formatString.replace(placeholderRegex, value);
}; // size is a number

var imageSize = function imageSize(src, size) {
  if (src.includes("cdn.accentuate")) {
    // if it is an accentuate image
    return "https://images.accentuate.io/?c_options=w_".concat(size, "&image=").concat(src);
  } else {
    // if shopify image
    var split = src.split(/\.(gif|jpe?g|png|bmp)/i);
    split.splice(1, 0, "_".concat(size, "x."));
    var newSrc = split.join("");
    return newSrc;
  }
};

/***/ }),

/***/ 481:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./scripts/services/service.event-bus.js
var service_event_bus = __webpack_require__(5);

// CONCATENATED MODULE: ./scripts/services/service.cart_new.js
/** 
 * Global Cart Service
 * Holds the current state of the cart
 * handles updating quantity and removing items
 * TODO : Move add to cart functionality here. 
 **/

function CartService() {
  var $this = {};
  $this.cart = false;
  $this.currentProduct = false;
  $this.productAdded = false;

  $this.init = function () {
    // $this.getCart();
    service_event_bus["a" /* default */].on(service_event_bus["a" /* default */].types.AddingToCart, $this.AddingToCart);
    service_event_bus["a" /* default */].on(service_event_bus["a" /* default */].types.AddedToCart, $this.addedToCart);
  };

  $this.addingToCart = function ($data) {
    $this.currentProduct = $data.detail;
  };

  $this.addedToCart = function ($data) {
    $this.productAdded = $data;
    $this.getCart();
  }; // $this.getCart = function(){
  //     $.get('/cart.json').done( function( res  ){
  //         $this.cart = res;
  //         eventBus.dispatch( eventBus.types.CartUpdated  , $this.cart )
  //     }) 
  // }
  // $this.removeItem = function( key   ){
  //     var params = {
  //         url: '/cart/change.js',
  //         data: { quantity: 0, id: key },
  //         dataType: 'json'
  //         };
  //     let $promise = new Promise(function(resolve, reject) {
  //         $.post(params)
  //         .done(
  //             function( res ) {
  //                 $this.cart = res;
  //                 resolve( { cart : res , success : true })
  //                 eventBus.dispatch( eventBus.RemovedFromCart ,  { cart : $this.cart , key : key } )
  //                 eventBus.dispatch( eventBus.types.CartUpdated  , $this.cart )
  //             }
  //         )
  //         .fail(
  //             function( res ) {
  //             resolve( { success : false })
  //             }
  //         );
  //         });
  //     return $promise;
  // }
  // $this.updateQuantity = function( key , value ){
  //     let $promise = new Promise(function(resolve, reject) {
  //         var params = {
  //             url: '/cart/change.js',
  //             data: { quantity: value, id: key },
  //             dataType: 'json'
  //         };
  //         $.post(params)
  //             .done( function( res ) { 
  //                 $this.cart = res;
  //                 resolve( { cart : res , success : true })
  //                 eventBus.dispatch( eventBus.types.CartUpdated  , $this.cart )
  //             } )
  //             .fail( function() { 
  //                     resolve( { success : false })
  //             } );			
  //     } );
  //     return $promise
  // }
  // $this.updateQuantity__update = function( updates ){
  //     let $promise = new Promise(function(resolve, reject) {
  //         var params = {
  //             url: '/cart/update.js',
  //             data: {  updates : updates } ,
  //             dataType: 'json'
  //         };
  //         $.post(params)
  //             .done( function( res ) { 
  //                 $this.cart = res;
  //                 resolve( { cart : res , success : true })
  //                 eventBus.dispatch( eventBus.types.CartUpdated  , $this.cart )
  //             } )
  //             .fail( function() { 
  //                     resolve( { success : false })
  //             } );			
  //     } );
  //     return $promise
  // }		


  return $this;
}
// EXTERNAL MODULE: ./scripts/utils/utils.js
var utils = __webpack_require__(1);

// CONCATENATED MODULE: ./scripts/components/component.navCart.js




var component_navCart_NavCart = function NavCart($containerElement) {
  var $this = {};
  $this.classes = {
    loading: 'loading',
    empty: 'empty'
  };

  $this.init = function () {
    $this.container = $containerElement;
    $this.count = Object(utils["k" /* selectDoc */])("[ws-count]", $this.container);
    service_event_bus["a" /* default */].on(service_event_bus["a" /* default */].types.AddingToCart, $this.addingToCart);
    service_event_bus["a" /* default */].on(service_event_bus["a" /* default */].types.AddedToCart, $this.addedToCart);
    service_event_bus["a" /* default */].on(service_event_bus["a" /* default */].types.CartUpdated, $this.cartUpdated);
  };

  $this.addingToCart = function () {
    Object(utils["a" /* addClass */])($this.container, $this.classes.loading);
  };

  $this.addedToCart = function ($data) {
    Object(utils["h" /* removeClass */])($this.container, $this.classes.loading);
  };

  $this.cartUpdated = function ($event) {
    var $count = /* Cannot get final name for export "default" in "./scripts/services/service.cart_new.js" (known exports: CartService, known reexports: ) */ undefined.cart.item_count;

    if ($count == 0) {
      Object(utils["a" /* addClass */])($this.container, $this.classes.empty); // $this.count.text( '')
    } else {
      Object(utils["h" /* removeClass */])($this.container, $this.classes.empty); // $this.count.text( $count )
    }
  };

  return $this;
};

/* harmony default export */ var component_navCart = __webpack_exports__["default"] = (component_navCart_NavCart);

/***/ }),

/***/ 5:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/** 
 * EventBus
 * Defines expected events
 * disppatches events by type
 * handles event listeners by type
 **/
var eventBus = {
  types: {
    AddingToCart: 'mx_shopify.cart.adding',
    AddedToCart: 'mx_shopify.cart.added',
    GettingCart: 'mx_shopify.cart.getting',
    CartUpdated: 'mx_shopify.cart.updated',
    RemovedFromCart: 'mx_shopify.cart.removed',
    QuantityUpdated: 'mx_shopify.quantity.updated',
    OptionsSelected: 'mx_shopify.options.selected',
    AjaxCartRefreshed: 'mx_shopify.cart.ajax.refreshed'
  },
  dispatch: function dispatch($event, $data) {
    $data = typeof $data !== 'undefined' ? $data : {};
    document.dispatchEvent(new CustomEvent($event, {
      detail: $data
    }));
  },
  on: function on($event, func) {
    document.addEventListener($event, func);
  },
  off: function off($event, func) {
    document.removeEventListener($event, func);
  }
};
/* harmony default export */ __webpack_exports__["a"] = (eventBus);

/***/ })

/******/ });
//# sourceMappingURL=component.navCart.js.map